# Gemini's Memory Bank: Somnus `virtual_machine` Subsystem

This document provides a comprehensive, in-depth analysis of the `virtual_machine` subsystem within the Somnus Sovereign Systems project. It details the architecture, components, and interaction flows that enable the creation and management of persistent, sovereign AI environments.

## Core Philosophy & Architecture

The `virtual_machine` subsystem is the bedrock of the Somnus project's "SaaS Killer" philosophy. It provides each AI instance with its own **persistent, stateful computer** in the form of a Virtual Machine (VM). This stands in stark contrast to traditional cloud AI services where sessions are stateless and ephemeral.

The architecture is a sophisticated, dual-layered, host-guest model:

1.  **Host-Side (The Supervisor Layer):** This layer runs on the host operating system. It is responsible for the complete lifecycle management of all VMs. It is the "god-level" controller that provisions, monitors, and manages the hardware and state of the AI's virtual computer.
2.  **Guest-Side (The In-VM Agentic Layer):** This layer runs *inside* each individual VM. It consists of the tools and agents that the AI itself uses to interact with its environment, perform tasks, and communicate with the host.

Communication between these two layers is not done through insecure, low-level protocols like direct SSH from the host. Instead, it's handled through two primary, secure, API-driven bridges:
*   The **`VMSupervisor`** on the host calls into the **`SomnusAgent`** in the guest to get health and metrics.
*   The **`AIActionOrchestrator`** in the guest calls out to the **`SovereignAIOrchestrator`** on the host to request actions and services.

## Component Breakdown

### Host-Side Components

These components run on the user's physical machine and manage the VMs from the outside.

#### 1. `vm_supervisor.py`: The VM Lifecycle Manager

*   **Purpose:** This is the most critical component on the host side. The `VMSupervisor` is a production-ready service that directly interfaces with the `libvirt` hypervisor API to perform all low-level VM operations.
*   **Key Features:**
    *   **Stateful & Persistent:** It loads and saves the configuration of every VM it manages from/to JSON files on disk, allowing it to survive restarts.
    *   **Efficient VM Creation:** It uses `qemu-img` to create VMs from a base image using **QCOW2 linked clones**, which is highly efficient for storage.
    *   **Dynamic Resource Scaling:** It can dynamically "hot-scale" a running VM's CPU and memory by applying predefined `ResourceProfile`s (e.g., "idle", "coding", "research").
    *   **Snapshot Management:** It provides robust, fully-implemented methods for creating and reverting VM snapshots, which is the foundation for safe, atomic capability installation.
    *   **Background Monitoring:** It runs a background thread to periodically poll the `SomnusAgent` inside each VM, collecting a historical record of runtime statistics.
    *   **Agent Client:** Contains the `SomnusVMAgentClient`, a dedicated HTTP client for communicating with the in-VM `SomnusAgent`.

#### 2. `ai_orchestrator.py`: The Sovereign AI Orchestrator

*   **Purpose:** This is the central "brain" of the entire Somnus system. The `SovereignAIOrchestrator` takes high-level user goals (e.g., "create a new AI for web development") and translates them into a sequence of actions across all other managers (`VMSupervisor`, `DevSessionManager`, etc.).
*   **Key Features:**
    *   **Orchestration Pattern:** It doesn't manage resources directly but instead directs the other managers, following a clean separation of concerns.
    *   **Capability Packs:** It uses a declarative, easily extensible system of `CAPABILITY_PACKS` to define how to set up different development environments.
    *   **Idempotent Provisioning:** Its main workflow, `provision_sovereign_environment`, is a robust, multi-step process that includes security validation, VM creation, session management, and capability installation.
    *   **Safe Installation:** It leverages the `VMSupervisor`'s snapshot feature to take a snapshot before installing each capability pack, enabling safe rollbacks on failure (though the rollback logic is a TODO).

### Guest-Side Components (In-VM)

These components run inside the AI's personal VM, giving it the tools to be autonomous and productive.

#### 1. `somnus_agent.py`: The In-VM Monitoring Agent

*   **Purpose:** The `SomnusAgent` is the host's "eyes and ears" inside the VM. It's a lightweight Flask-based agent that provides health, metrics, and intelligent log analysis back to the `VMSupervisor`.
*   **Key Features:**
    *   **API for the Host:** Exposes a simple, local API for the `VMSupervisor` to query.
    *   **Health & Readiness Probes:** Implements standard `/health/live` and `/health/ready` endpoints for robust monitoring.
    *   **Semantic Log Analysis:** Its most innovative feature. It uses a `sentence-transformer` model to semantically analyze error logs, allowing it to classify errors by meaning, not just keywords. It includes a keyword-based fallback for resilience.
    *   **Soft Reboot Capability:** Provides a `/soft-reboot` endpoint that allows the host to gracefully restart the AI's core processes without rebooting the entire VM.

#### 2. `ai_action_orchestrator.py`: The AI's Hand and Voice

*   **Purpose:** This is the in-VM counterpart to the host's `SovereignAIOrchestrator`. It is the primary tool the AI uses to interact with the host system and request actions. It abstracts away direct control over host resources, replacing it with a secure, structured API.
*   **Key Features:**
    *   **Secure API Bridge:** It contains the `AIActionClient`, which communicates with the host's API using a unique, injected authentication token. This is the fundamental security model for host-guest interaction.
    *   **High-Level Workflows:** It provides the AI with simple, high-level methods like `create_and_setup_artifact` and `execute_code_in_artifact`, which translate into a series of authenticated API calls to the host.
    *   **Integrated Memory:** Includes a `remember_result` method, allowing the AI to consciously decide to store information in its long-term memory via an API call.

#### 3. `advanced_ai_shell.py`: The AI's Power Tool

*   **Purpose:** The `AdvancedAIShell` is the AI's primary interface for executing commands and orchestrating complex tasks. It's a unified shell that understands different execution contexts.
*   **Key Features:**
    *   **Multi-Context Execution:** It can intelligently route commands to be executed in different contexts:
        *   `VM_NATIVE`: Directly within its own persistent VM.
        *   `CONTAINER_OVERLAY`: In a disposable, isolated Docker container managed by the host.
        *   `MULTI_AGENT`: Delegated to a network of other collaborating AI agents.
    *   **Container & Collaboration Management:** It contains a `ContainerOrchestrator` and `CollaborationManager` to handle the complexities of these execution contexts, including creating containers and managing peer-to-peer connections with other agents.

#### 4. `ai_personal_dev_template.py`: The AI's Evolving Toolkit

*   **Purpose:** This component gives the AI the ability to manage its own development environment and become a better developer over time.
*   **Key Features:**
    *   **Automated Workspace Setup:** It can automate the entire process of setting up a new project: installing tools, creating directory structures, initializing git, and configuring the IDE.
    *   **Evolving Preferences:** It stores the AI's preferences (IDEs, coding styles) and tracks its own `efficiency_rating` for different tasks, creating a feedback loop for self-improvement.
    *   **Personal Libraries:** It allows the AI to create its own reusable code libraries, which are then registered as formal artifacts in the Somnus system.

#### 5. `ai_browser_research_system.py`: The AI's Research Assistant

*   **Purpose:** This is a highly advanced, in-VM system for conducting automated, browser-based research.
*   **Key Features:**
    *   **Multi-Phase Research:** It mimics a human researcher by breaking tasks into phases: planning, searching, deep reading, cross-referencing, and synthesis.
    *   **Critical Analysis:** It doesn't just scrape data. It attempts to analyze source credibility, detect bias, identify contradictions, and find consensus among sources.
    *   **Artifact Generation:** The final output is a structured Markdown report and a JSON data file, which are created as artifacts.
    *   **Placeholder-Heavy:** Many of the advanced analysis functions are currently simplified placeholders that rely on keyword matching and require more sophisticated NLP models to be fully realized.

## Interaction Flow: Provisioning a New AI

1.  A user requests a new AI environment via the main Somnus application.
2.  The **`SovereignAIOrchestrator`** receives the request.
3.  It calls the **`VMSupervisor`** to provision a new VM from a base image.
4.  The `VMSupervisor` creates the VM, starts it, and injects the necessary configuration, including a unique auth token for the **`AIActionOrchestrator`**.
5.  The `SovereignAIOrchestrator` then takes a snapshot of the clean VM via the `VMSupervisor`.
6.  It proceeds to install the requested `CAPABILITY_PACKS`, executing the installation commands inside the VM. After each successful installation, it takes another snapshot.
7.  Once provisioning is complete, the AI is "alive" inside its VM. It has the **`SomnusAgent`** for monitoring, the **`AIActionOrchestrator`** to talk to the host, and the **`AdvancedAIShell`** and other tools to perform its tasks.