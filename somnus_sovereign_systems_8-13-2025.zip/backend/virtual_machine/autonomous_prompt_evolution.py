
Somnus: Autonomous Prompt Evolution Engine
Handles the automatic, data-driven evolution of system prompts.
"""
import json
import hashlib
from pathlib import Path
import time
import uuid
from typing import Dict, List, Optional, Any, Tuple, Union
from dataclasses import dataclass, asdict, field
from abc import ABC, abstractmethod
from enum import Enum
import logging
import asyncio
from datetime import datetime, timedelta
import numpy as np
import torch
from collections import defaultdict

# Corrected imports for Somnus architecture
from ....core.memory_core import MemoryManager, MemoryType, MemoryConfiguration, MemoryImportance as CoreMemoryImportance
from ....core.model_loader import ModelLoader
from ....schemas.models import ModelID

# Third-party imports
from sentence_transformers import SentenceTransformer, util
from transformers import Pipeline

# --- System Configuration ---

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - [%(levelname)s] - %(message)s')
logger = logging.getLogger(__name__)

# A unique identifier for the evolution system's own memories
SYSTEM_USER_ID = "AutonomousPromptEvolutionEngine"

# --- Enums and Data Models ---

class MemoryImportance(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    TEMPORARY = "temporary"

class PromptEvolutionStatus(Enum):
    ACTIVE = "active"
    TESTING = "testing"
    DEPRECATED = "deprecated"
    FAILED = "failed"

class InteractionOutcome(Enum):
    SUCCESS = "success"
    PARTIAL_SUCCESS = "partial_success"
    FAILURE = "failure"
    ERROR = "error"

@dataclass
class InteractionMemory:
    """Represents a stored interaction for learning purposes"""
    interaction_id: str
    timestamp: datetime
    prompt_id: str
    user_input: str
    ai_response: str
    outcome: InteractionOutcome
    performance_score: float
    context: Dict[str, Any]
    memory_id: Optional[str] = None

@dataclass
class PromptPerformanceMetrics:
    """Performance metrics for a prompt variant"""
    prompt_id: str
    total_interactions: int
    success_rate: float
    average_score: float
    user_satisfaction: float
    task_completion_rate: float
    error_rate: float
    last_updated: datetime
    trend_direction: str

@dataclass
class BehavioralPattern:
    """Identified behavioral pattern from memory analysis"""
    pattern_id: str
    description: str
    success_contexts: List[str]
    failure_contexts: List[str]
    confidence_score: float
    usage_frequency: int
    last_seen: datetime

@dataclass
class EvolutionaryPrompt:
    """Self-modifying prompt with memory integration"""
    prompt_id: str
    name: str
    base_template: str
    dynamic_components: Dict[str, str]
    generation: int
    parent_id: Optional[str]
    status: PromptEvolutionStatus
    performance_metrics: PromptPerformanceMetrics
    memory_context_ids: List[str]
    behavioral_patterns: List[str]
    created_at: datetime
    last_modified: datetime
    metadata: Dict[str, Any]

# --- Abstract Interfaces for Pluggability ---
# (These remain the same as they define the contract)

class EvaluationInterface(ABC):
    @abstractmethod
    async def evaluate_interaction(self, prompt_content: str, user_input: str, ai_response: str, context: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
        pass

class SafetyInterface(ABC):
    @abstractmethod
    async def validate_prompt_safety(self, prompt_content: str) -> Tuple[bool, List[str]]:
        pass

    @abstractmethod
    async def check_behavioral_drift(self, old_prompt: str, new_prompt: str) -> Tuple[bool, float]:
        pass

# --- Core Evolution Engine ---

class AutonomousPromptEvolutionEngine:
    """
    Manages the entire lifecycle of prompt evolution, from performance tracking
    to mutation and validation, integrated with Somnus core systems.
    """
    def __init__(self,
                 memory_manager: MemoryManager,
                 model_loader: ModelLoader,
                 evaluation_model_id: ModelID,
                 config: Optional[Dict[str, Any]] = None):
        """
        Initializes the engine with core Somnus services.

        Args:
            memory_manager: An initialized instance of MemoryManager.
            model_loader: An initialized instance of ModelLoader.
            evaluation_model_id: The ID of the model registered in ModelLoader to be used for evaluation tasks.
            config: Optional dictionary for custom configuration.
        """
        self.memory = memory_manager
        self.model_loader = model_loader
        self.evaluation_model_id = evaluation_model_id
        self.config = self._default_config()
        if config:
            self.config.update(config)

        # Interfaces for evaluation and safety
        self.evaluator = ProductionEvaluationInterface(self)
        self.safety = ProductionSafetyInterface(self, self.memory.config.embedding_model)

        # Internal state
        self.active_prompts: Dict[str, EvolutionaryPrompt] = {}
        self.behavioral_patterns: Dict[str, BehavioralPattern] = {}
        self.interaction_history: List[InteractionMemory] = []
        self.evolution_lock = asyncio.Lock()

        logger.info(f"Autonomous Prompt Evolution Engine initialized with evaluation model '{evaluation_model_id}'.")

    def _default_config(self) -> Dict[str, Any]:
        return {
            "evolution_frequency_hours": 24,
            "min_interactions_for_evolution": 50,
            "performance_threshold": 0.75,
            "max_drift_score": 0.4,
            "pattern_confidence_threshold": 0.8,
            "memory_lookback_days": 30,
            "max_active_variants": 5,
            "mutation_rate": 0.1,
            "crossover_rate": 0.3,
            "min_interactions_for_validation": 20,
        }

    async def _generate_with_eval_model(self, prompt: str, json_output: bool = False) -> Union[str, Dict, List]:
        """Helper to generate text or JSON using the designated evaluation model."""
        model_data = self.model_loader.get_loaded_model(self.evaluation_model_id)
        if not model_data or not model_data.get("pipeline"):
            raise RuntimeError(f"Evaluation model '{self.evaluation_model_id}' is not loaded or has no pipeline.")

        pipeline = model_data["pipeline"]
        
        full_prompt = prompt
        if json_output:
            full_prompt += "\n\nRespond with only a valid JSON object, without any markdown formatting or other text."

        try:
            # The pipeline from transformers returns a list of dictionaries
            result = pipeline(full_prompt, max_new_tokens=2048, do_sample=True, temperature=0.5)
            generated_text = result[0]['generated_text']
            
            # The pipeline often includes the prompt in the output, so we remove it.
            response_text = generated_text[len(full_prompt):].strip()

            if json_output:
                return json.loads(response_text)
            return response_text
        except json.JSONDecodeError as e:
            logger.error(f"Failed to decode JSON from LLM response: {e}\nResponse was: {response_text}")
            raise
        except Exception as e:
            logger.error(f"Error during model generation: {e}", exc_info=True)
            raise

    async def initialize_from_memory(self):
        """Initialize the system by loading prompts and patterns from memory"""
        logger.info("Initializing evolution engine from memory...")
        
        prompt_memories = await self.memory.retrieve_memories(
            user_id=SYSTEM_USER_ID,
            query="evolutionary prompt artifact",
            memory_types=[MemoryType.CUSTOM_INSTRUCTION],
            limit=100
        )
        
        for memory in prompt_memories:
            try:
                prompt_data = json.loads(memory.get("content", "{}"))
                if "prompt_id" in prompt_data:
                    metrics_data = prompt_data.get("performance_metrics", {})
                    prompt_data["performance_metrics"] = PromptPerformanceMetrics(**metrics_data)
                    prompt_data["created_at"] = datetime.fromisoformat(prompt_data["created_at"])
                    prompt_data["last_modified"] = datetime.fromisoformat(prompt_data["last_modified"])
                    prompt_data["status"] = PromptEvolutionStatus(prompt_data["status"])
                    
                    prompt = EvolutionaryPrompt(**prompt_data)
                    self.active_prompts[prompt.prompt_id] = prompt
            except Exception as e:
                logger.warning(f"Failed to load prompt from memory {memory.get('memory_id')}: {e}")
        
        pattern_memories = await self.memory.retrieve_memories(
            user_id=SYSTEM_USER_ID,
            query="discovered behavioral pattern",
            memory_types=[MemoryType.SYSTEM_EVENT],
            limit=200
        )
        
        for memory in pattern_memories:
            try:
                pattern_data = json.loads(memory.get("content", "{}"))
                if "pattern_id" in pattern_data:
                    pattern_data["last_seen"] = datetime.fromisoformat(pattern_data["last_seen"])
                    pattern = BehavioralPattern(**pattern_data)
                    self.behavioral_patterns[pattern.pattern_id] = pattern
            except Exception as e:
                logger.warning(f"Failed to load pattern from memory {memory.get('memory_id')}: {e}")
                
        logger.info(f"Loaded {len(self.active_prompts)} prompts and {len(self.behavioral_patterns)} patterns from memory")

    async def record_interaction(self, prompt_id: str, user_input: str, 
                               ai_response: str, context: Dict[str, Any]):
        """Record an interaction for learning and evolution"""
        score, detailed_metrics = await self.evaluator.evaluate_interaction(
            prompt_content=await self._get_prompt_content(prompt_id),
            user_input=user_input,
            ai_response=ai_response,
            context=context
        )
        
        outcome = self._determine_interaction_outcome(score, detailed_metrics)
        
        interaction = InteractionMemory(
            interaction_id=str(uuid.uuid4()),
            timestamp=datetime.now(),
            prompt_id=prompt_id,
            user_input=user_input,
            ai_response=ai_response,
            outcome=outcome,
            performance_score=score,
            context=context
        )
        
        memory_content = json.dumps(asdict(interaction), default=str)
        importance = self._determine_memory_importance(outcome, score)
        tags = self._generate_interaction_tags(interaction, context)
        
        memory_id = await self.memory.store_memory(
            user_id=SYSTEM_USER_ID,
            content=memory_content,
            memory_type=MemoryType.INTERACTION,
            importance=CoreMemoryImportance(importance.value),
            tags=tags,
            metadata={"performance_score": score, "outcome": outcome.value}
        )
        
        interaction.memory_id = str(memory_id)
        self.interaction_history.append(interaction)
        
        await self._update_prompt_metrics(prompt_id, interaction)
        await self._maybe_trigger_evolution(prompt_id)
        
        logger.debug(f"Recorded interaction {interaction.interaction_id} with score {score}")

    async def autonomous_evolution_cycle(self):
        """Main autonomous evolution cycle - runs periodically"""
        async with self.evolution_lock:
            logger.info("Starting autonomous evolution cycle...")
            try:
                new_patterns = await self._discover_behavioral_patterns()
                for pattern in new_patterns:
                    if pattern.pattern_id not in self.behavioral_patterns:
                        self.behavioral_patterns[pattern.pattern_id] = pattern
                        await self._store_pattern_in_memory(pattern)
                
                underperforming_prompts = await self._identify_underperforming_prompts()
                
                for prompt_id in underperforming_prompts:
                    await self._evolve_prompt(prompt_id)
                
                await self._validate_prompt_variants()
                await self._cleanup_deprecated_prompts()
                
                logger.info("Autonomous evolution cycle completed successfully")
            except Exception as e:
                logger.error(f"Error in evolution cycle: {e}", exc_info=True)

    async def _evolve_prompt(self, prompt_id: str):
        """Evolve a specific prompt based on memory analysis and LLM-driven strategies."""
        current_prompt = self.active_prompts.get(prompt_id)
        if not current_prompt:
            logger.warning(f"Attempted to evolve non-existent prompt {prompt_id}")
            return

        logger.info(f"Evolving prompt {prompt_id} (gen {current_prompt.generation})")

        # 1. Gather evidence from memory
        failure_memories = await self.memory.retrieve_memories(
            user_id=SYSTEM_USER_ID,
            query=f"interaction failure for prompt {prompt_id}",
            memory_types=[MemoryType.INTERACTION],
            importance_threshold=CoreMemoryImportance.MEDIUM,
            limit=50
        )

        success_memories = await self.memory.retrieve_memories(
            user_id=SYSTEM_USER_ID,
            query=f"high performing interaction success pattern for prompt {prompt_id}",
            memory_types=[MemoryType.INTERACTION],
            importance_threshold=CoreMemoryImportance.MEDIUM,
            limit=50
        )

        # 2. Generate evolution strategies with LLM
        evolution_strategies = await self._generate_evolution_strategies(
            current_prompt, failure_memories, success_memories
        )

        if not evolution_strategies:
            logger.info(f"No evolution strategies generated for prompt {prompt_id}. Skipping.")
            return

        # 3. Apply strategies and create new variants
        for strategy in evolution_strategies:
            try:
                new_template = await self._apply_strategy_modifications(current_prompt.base_template, strategy)

                # 4. Safety Checks
                is_safe, warnings = await self.safety.validate_prompt_safety(new_template)
                if not is_safe:
                    logger.warning(f"Evolved prompt variant failed safety check: {warnings}")
                    continue

                is_safe_drift, drift_score = await self.safety.check_behavioral_drift(
                    current_prompt.base_template, new_template
                )
                if not is_safe_drift:
                    logger.warning(f"Evolved prompt variant has unsafe behavioral drift: {drift_score:.2f}")
                    continue

                # 5. Create and store the new variant
                new_prompt = self._create_prompt_variant(current_prompt, new_template, strategy)
                self.active_prompts[new_prompt.prompt_id] = new_prompt
                await self._store_prompt_in_memory(new_prompt)
                
                logger.info(f"Created new prompt variant {new_prompt.prompt_id} (gen {new_prompt.generation}) with drift score {drift_score:.2f}")

            except Exception as e:
                logger.error(f"Failed to apply strategy for prompt {prompt_id}: {e}", exc_info=True)

    async def _generate_evolution_strategies(self, current_prompt: EvolutionaryPrompt, 
                                           failure_memories: List[Dict], 
                                           success_memories: List[Dict]) -> List[Dict[str, Any]]:
        """Generate evolution strategies using LLM."""
        failure_summary = "\n".join([json.dumps(m.get('content')) for m in failure_memories])
        success_summary = "\n".join([json.dumps(m.get('content')) for m in success_memories])

        llm_prompt = (
            f"You are a prompt engineering expert. Given the following prompt and analysis, devise up to 3 distinct evolution strategies.\n"
            f"CURRENT PROMPT:\n---\n{current_prompt.base_template}\n---\n"
            f"ANALYSIS:\n"
            f"- Recent Failure Patterns: {failure_summary or 'None'}\n"
            f"- Recent Success Patterns: {success_summary or 'None'}\n"
            f"- Relevant Behavioral Patterns: {[p.description for p in self.behavioral_patterns.values() if p.confidence_score > 0.8]}\n\n"
            "For each strategy, provide a 'type' (e.g., 'failure_mitigation', 'success_adoption', 'pattern_integration', 'mutation') "
            "and a 'description' of the change to make. Format as a JSON array of objects."
        )
        
        try:
            strategies = await self._generate_with_eval_model(llm_prompt, json_output=True)
            return strategies if isinstance(strategies, list) else []
        except Exception as e:
            logger.error(f"Failed to generate evolution strategies via LLM: {e}")
            return []

    async def _apply_strategy_modifications(self, base_template: str, strategy: Dict[str, Any]) -> str:
        """Apply evolution strategy modifications to prompt template using LLM."""
        llm_prompt = (
            f"You are a prompt engineering expert. Apply the following modification to the base prompt.\n"
            f"BASE PROMPT:\n---\n{base_template}\n---\n"
            f"MODIFICATION STRATEGY:\n"
            f"- Type: {strategy.get('type')}\n"
            f"- Description: {strategy.get('description')}\n\n"
            "Output only the new, modified prompt, without any preamble."
        )
        return await self._generate_with_eval_model(llm_prompt)

    def _create_prompt_variant(self, parent_prompt: EvolutionaryPrompt, 
                                   new_template: str, strategy: Dict[str, Any]) -> EvolutionaryPrompt:
        """Create a new prompt variant based on evolution strategy."""
        new_id = str(uuid.uuid4())
        return EvolutionaryPrompt(
            prompt_id=new_id,
            name=f"{parent_prompt.name}_gen{parent_prompt.generation + 1}",
            base_template=new_template,
            dynamic_components=parent_prompt.dynamic_components.copy(),
            generation=parent_prompt.generation + 1,
            parent_id=parent_prompt.prompt_id,
            status=PromptEvolutionStatus.TESTING,
            performance_metrics=PromptPerformanceMetrics(
                prompt_id=new_id, total_interactions=0, success_rate=0.0,
                average_score=0.0, user_satisfaction=0.0, task_completion_rate=0.0,
                error_rate=0.0, last_updated=datetime.now(), trend_direction="stable"
            ),
            memory_context_ids=[],
            behavioral_patterns=[strategy.get("type", "unknown")],
            created_at=datetime.now(),
            last_modified=datetime.now(),
            metadata={"evolution_strategy": strategy}
        )

    async def _discover_behavioral_patterns(self) -> List[BehavioralPattern]:
        """Discover new behavioral patterns from recent memory using LLM analysis"""
        cutoff_date = datetime.now() - timedelta(days=self.config["memory_lookback_days"])
        
        recent_successes = await self.memory.retrieve_memories(
            user_id=SYSTEM_USER_ID,
            query="successful interaction high performance",
            memory_types=[MemoryType.INTERACTION],
            importance_threshold=CoreMemoryImportance.MEDIUM,
            limit=200
        )
        
        # Filter memories by date client-side
        valid_memories = []
        for mem in recent_successes:
            try:
                # Assuming the memory dictionary has a 'created_at' field.
                timestamp_str = mem.get('created_at')
                if timestamp_str:
                    timestamp = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                    if timestamp.tzinfo is None:
                        timestamp = timestamp.replace(tzinfo=timezone.utc)
                    if timestamp >= cutoff_date.replace(tzinfo=timezone.utc):
                        valid_memories.append(mem)
            except (ValueError, TypeError) as e:
                logger.warning(f"Skipping memory during pattern discovery due to data issue: {e}")
                continue

        if len(valid_memories) < 20:
            logger.info("Not enough recent successful memories to discover new patterns.")
            return []

        # Use LLM to identify and summarize patterns
        memory_dump = "\n".join([json.dumps(m.get('content')) for m in valid_memories])
        llm_prompt = (
            "Analyze the following successful interaction logs. Identify up to 5 recurring behavioral patterns "
            "that lead to success. For each pattern, provide a concise description and a list of contexts "
            "(e.g., task types) where it is most effective.\n\n"
            f"Logs:\n{memory_dump}\n\n"
            "Format your response as a JSON array of objects, each with 'description' and 'success_contexts' keys."
        )
        
        try:
            raw_patterns = await self._generate_with_eval_model(llm_prompt, json_output=True)
            if not isinstance(raw_patterns, list):
                return []

            discovered_patterns = []
            for p_data in raw_patterns:
                description = p_data.get('description')
                if not description: continue

                pattern = BehavioralPattern(
                    pattern_id=hashlib.sha256(description.encode()).hexdigest()[:12],
                    description=description,
                    success_contexts=p_data.get('success_contexts', []),
                    failure_contexts=[],
                    confidence_score=self.config["pattern_confidence_threshold"], # Assign initial confidence
                    usage_frequency=1, # Placeholder
                    last_seen=datetime.now()
                )
                discovered_patterns.append(pattern)
            
            logger.info(f"Discovered {len(discovered_patterns)} new behavioral patterns via LLM analysis.")
            return discovered_patterns
        except Exception as e:
            logger.error(f"Failed to discover patterns via LLM: {e}")
            return []

    async def _get_prompt_content(self, prompt_id: str) -> str:
        prompt = self.active_prompts.get(prompt_id)
        return prompt.base_template if prompt else ""

    def _determine_interaction_outcome(self, score: float, metrics: Dict[str, Any]) -> InteractionOutcome:
        if "error" in metrics and metrics["error"]:
            return InteractionOutcome.ERROR
        if score >= 0.85:
            return InteractionOutcome.SUCCESS
        elif score >= 0.6:
            return InteractionOutcome.PARTIAL_SUCCESS
        else:
            return InteractionOutcome.FAILURE

    def _determine_memory_importance(self, outcome: InteractionOutcome, score: float) -> MemoryImportance:
        if outcome == InteractionOutcome.SUCCESS and score >= 0.95:
            return MemoryImportance.CRITICAL
        elif outcome == InteractionOutcome.SUCCESS:
            return MemoryImportance.HIGH
        elif outcome == InteractionOutcome.FAILURE:
            return MemoryImportance.HIGH
        elif outcome == InteractionOutcome.PARTIAL_SUCCESS:
            return MemoryImportance.MEDIUM
        else:
            return MemoryImportance.LOW

    def _generate_interaction_tags(self, interaction: InteractionMemory, context: Dict[str, Any]) -> List[str]:
        tags = [
            f"prompt_{interaction.prompt_id}",
            f"outcome_{interaction.outcome.value}",
            f"score_{int(interaction.performance_score * 10)}",
        ]
        if "task_type" in context:
            tags.append(f"task_{context['task_type']}")
        return tags

    async def _update_prompt_metrics(self, prompt_id: str, interaction: InteractionMemory):
        if prompt_id not in self.active_prompts: return
        
        prompt = self.active_prompts[prompt_id]
        metrics = prompt.performance_metrics
        
        total = metrics.total_interactions
        metrics.average_score = (metrics.average_score * total + interaction.performance_score) / (total + 1)
        
        success_count = metrics.success_rate * total
        if interaction.outcome == InteractionOutcome.SUCCESS:
            success_count += 1
        metrics.success_rate = success_count / (total + 1)
        
        error_count = metrics.error_rate * total
        if interaction.outcome == InteractionOutcome.ERROR:
            error_count += 1
        metrics.error_rate = error_count / (total + 1)

        metrics.total_interactions += 1
        metrics.last_updated = datetime.now()
        
        await self._store_prompt_in_memory(prompt)

    async def _maybe_trigger_evolution(self, prompt_id: str):
        if prompt_id not in self.active_prompts: return
        
        prompt = self.active_prompts[prompt_id]
        metrics = prompt.performance_metrics
        
        if metrics.total_interactions >= self.config["min_interactions_for_evolution"]:
            if metrics.average_score < self.config["performance_threshold"]:
                logger.info(f"Triggering evolution for underperforming prompt {prompt_id} (avg score: {metrics.average_score:.2f})")
                await self._evolve_prompt(prompt_id)

    async def _identify_underperforming_prompts(self) -> List[str]:
        return [
            pid for pid, p in self.active_prompts.items()
            if p.status == PromptEvolutionStatus.ACTIVE and
               p.performance_metrics.total_interactions >= self.config["min_interactions_for_evolution"] and
               p.performance_metrics.average_score < self.config["performance_threshold"]
        ]
    
    async def _store_prompt_in_memory(self, prompt: EvolutionaryPrompt):
        content = json.dumps(asdict(prompt), default=str)
        await self.memory.store_memory(
            user_id=SYSTEM_USER_ID,
            content=content,
            memory_type=MemoryType.CUSTOM_INSTRUCTION,
            importance=CoreMemoryImportance.HIGH,
            tags=["evolutionary_prompt", f"generation_{prompt.generation}", prompt.status.value],
            metadata={"prompt_id": prompt.prompt_id, "generation": prompt.generation}
        )
    
    async def _store_pattern_in_memory(self, pattern: BehavioralPattern):
        content = json.dumps(asdict(pattern), default=str)
        await self.memory.store_memory(
            user_id=SYSTEM_USER_ID,
            content=content,
            memory_type=MemoryType.SYSTEM_EVENT,
            importance=CoreMemoryImportance.HIGH,
            tags=["pattern", f"confidence_{int(pattern.confidence_score * 10)}"],
            metadata={"pattern_id": pattern.pattern_id, "confidence": pattern.confidence_score}
        )
    
    async def _validate_prompt_variants(self):
        """Validate and promote or fail successful prompt variants based on performance."""
        testing_prompts = [p for p in self.active_prompts.values() 
                          if p.status == PromptEvolutionStatus.TESTING]
        
        for prompt in testing_prompts:
            metrics = prompt.performance_metrics
            if metrics.total_interactions >= self.config.get("min_interactions_for_validation", 20):
                parent_prompt = self.active_prompts.get(prompt.parent_id)
                # If there's no parent, compare against the system's performance threshold
                parent_score = parent_prompt.performance_metrics.average_score if parent_prompt else self.config["performance_threshold"]

                if metrics.average_score > parent_score:
                    prompt.status = PromptEvolutionStatus.ACTIVE
                    logger.info(f"Promoted prompt variant {prompt.prompt_id} to ACTIVE (score: {metrics.average_score:.2f} > {parent_score:.2f})")
                    # Deprecate the parent to favor the new, better version
                    if parent_prompt:
                        parent_prompt.status = PromptEvolutionStatus.DEPRECATED
                        await self._store_prompt_in_memory(parent_prompt)
                else:
                    prompt.status = PromptEvolutionStatus.FAILED
                    logger.info(f"Marked prompt variant {prompt.prompt_id} as FAILED (score: {metrics.average_score:.2f} <= {parent_score:.2f})")
                
                await self._store_prompt_in_memory(prompt)

    async def _cleanup_deprecated_prompts(self):
        """Clean up old and failed prompt variants from active list."""
        cutoff_date = datetime.now() - timedelta(days=self.config.get("deprecated_cleanup_days", 60))
        to_remove = [
            pid for pid, p in self.active_prompts.items()
            if p.status == PromptEvolutionStatus.FAILED or 
               (p.status == PromptEvolutionStatus.DEPRECATED and p.last_modified < cutoff_date)
        ]
        
        for prompt_id in to_remove:
            del self.active_prompts[prompt_id]
            # Optionally, you could add logic here to remove them from the MemoryManager
            # if long-term storage is a concern and you don't need historical data.
            logger.info(f"Cleaned up deprecated prompt {prompt_id}")

# --- Production-Grade Interface Implementations ---

class ProductionEvaluationInterface(EvaluationInterface):
    def __init__(self, engine: AutonomousPromptEvolutionEngine):
        self.engine = engine

    async def evaluate_interaction(self, prompt_content: str, user_input: str, ai_response: str, context: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
        llm_prompt = (
            "You are an expert AI interaction evaluator. Evaluate the following "
            "interaction on a scale of 0.0 to 1.0 based on relevance, accuracy, "
            "clarity, and safety. Provide a single overall 'score' and a dictionary "
            "of 'detailed_metrics'. Respond with a JSON object.\n\n"
            f"CONTEXT: {json.dumps(context)}\n"
            f"PROMPT: {prompt_content}\n"
            f"USER INPUT: {user_input}\n"
            f"AI RESPONSE: {ai_response}\n"
        )
        try:
            result = await self.engine._generate_with_eval_model(llm_prompt, json_output=True)
            score = float(result.get("score", 0.0))
            score = max(0.0, min(1.0, score))
            metrics = result.get("detailed_metrics", {})
            return score, metrics
        except Exception as exc:
            logger.error(f"LLM evaluation failed: {exc} – returning safe fallback score", exc_info=True)
            return 0.0, {"error": str(exc), "fallback": True}

class ProductionSafetyInterface(SafetyInterface):
    def __init__(self, engine: AutonomousPromptEvolutionEngine, embedding_model_name: str):
        self.engine = engine
        self.encoder = SentenceTransformer(embedding_model_name)

    async def validate_prompt_safety(self, prompt_content: str) -> Tuple[bool, List[str]]:
        llm_prompt = (
            "You are a safety validation expert. Analyze the following prompt for any "
            "harmful, unethical, or dangerous content. Respond with a JSON object "
            "containing 'is_safe' (boolean) and 'warnings' (list of strings).\n\n"
            f"PROMPT: {prompt_content}"
        )
        try:
            result = await self.engine._generate_with_eval_model(llm_prompt, json_output=True)
            is_safe = bool(result.get("is_safe", False))
            warnings = result.get("warnings", [])
            return is_safe, warnings
        except Exception as exc:
            logger.error(f"Safety validation LLM failed: {exc} – treating as unsafe", exc_info=True)
            return False, [f"LLM failure: {exc}"]

    async def check_behavioral_drift(self, old_prompt: str, new_prompt: str) -> Tuple[bool, float]:
        try:
            embeddings = self.encoder.encode([old_prompt, new_prompt], convert_to_tensor=True)
            similarity = util.pytorch_cos_sim(embeddings[0], embeddings[1]).item()
            drift_score = 1.0 - similarity
            is_safe = drift_score < self.engine.config['max_drift_score']
            return is_safe, drift_score
        except Exception as exc:
            logger.error(f"Embedding-based drift calculation failed: {exc} – returning unsafe", exc_info=True)
            return False, 1.0
