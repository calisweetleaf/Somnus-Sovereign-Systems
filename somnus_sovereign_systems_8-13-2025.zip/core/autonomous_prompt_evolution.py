import json
import hashlib
from pathlib import Path
import time
import yaml
import torch
import uuid
from typing import Dict, List, Optional, Any, Tuple, Union
from dataclasses import dataclass, asdict, field
from abc import ABC, abstractmethod
from enum import Enum
import logging
import asyncio
from datetime import datetime, timedelta
import numpy as np
import httpx
import os
from cas.model_creation import compute_sha256_file
import defaultdict
from path import path
from sentence_transformers import SentenceTransformer, util
import path

# Somnus memory system imports
from ..vm_memory_system.memory_core import MemoryManager, MemoryType, MemoryConfiguration
from ..vm_memory_system.memory_core import MemoryImportance as CoreMemoryImportance

# Somnus model loader imports
from ..vm.model_loader import ProductionMemoryInterface
import vm.model_loader as create
from ..vm.model_loader import ModelLoader, ModelLoaderConfig
from model_creation import LLMProvider # Provides missing endpoints and configurations not allowed from model_loader.py
from model_creation import (
    ModelFileLoader, ModelFileDirectory, GenerateModelFile,
    CustomModelName, CustomModelFile, CustomModelType,
    ModelConfigReportManager, ModelParameterReport, GenerateModelParamtersFile
)

from .model_parameters import ModelName, ModelFileTemplate, ModelParameters #general term for base abilities of whatever model. This includes parameters, max output length, max context length, etc. No functionality of the system is based on any of the model reports, or the model_config, besides the modelfile generation. The rest of the reports are for ultimate "auditability."


# --- System Configuration ---

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - [%(levelname)s] - %(message)s')
logger = logging.getLogger(__name__)

# --- LLM API Configuration (Replace with actual endpoint and key) ---
LLM_API_URL = "https://api.example.com/v1/chat/completions"
MSTY_ENDPOINT_URL = "https://api.msty.com/v1/llm"
LMSTUDIO_ENDPOINT_URL = "https://api.lmstudio.com/v1/llm"
OLLAMA_API_KEY = "YOUR_OLLAMA_API_KEY_HERE" 
MSTY_API_KEY = "YOUR_MSTY_API_KEY_HERE"
LMSTUDIO_API_KEY = "YOUR_LMSTUDIO_API_KEY_HERE"
OLLAMA_MODEL_NAME = "llama3-70b-chat"  
OLLAMA_MODEL_FILE = "llama3-70b-chat.bin" 
LMSTUDIO_MODEL_NAME = "llama3-70b-chat"
MSTY_MODEL_NAME = "msty-llama3-70b-chat"
LLM_API_HEADERS = {
    "Authorization": f"Bearer {OLLAMA_API_KEY}",
    "Ollama-Model": OLLAMA_MODEL_NAME,
    "Ollama-Model-File": OLLAMA_MODEL_FILE,
    "Msty-Api-Key": MSTY_API_KEY,
    "Lmstudio-Api-Key": LMSTUDIO_API_KEY,
    
    "Content-Type": "application/json"
}
# A unique identifier for the evolution system's own memories
SYSTEM_USER_ID = "Morpheus"
SYSTEM_MODEL_ID = "user-configurable"
MODEL_TYPE = " MSTY, LMSTUDIO, OLLAMA, or local Python model"
MODEL_NAME = "YOUR_CUSTOM_MODEL_NAME_HERE"
MODEL_FILE = "PATH_TO_YOUR_MODEL_FILE_HERE"

class MemoryImportance(Enum):
    CRITICAL = "critical"
    HIGH = "high" 
    MEDIUM = "medium"
    LOW = "low"
    TEMPORARY = "temporary"

class PromptEvolutionStatus(Enum):
    ACTIVE = "active"
    TESTING = "testing"
    DEPRECATED = "deprecated"
    FAILED = "failed"

class InteractionOutcome(Enum):
    SUCCESS = "success"
    PARTIAL_SUCCESS = "partial_success"
    FAILURE = "failure"
    ERROR = "error"

# --- Abstract Interfaces for Pluggability ---

class MemoryInterface(ABC):
    """Abstract interface for memory system integration"""
    
    @abstractmethod
    async def store_memory(self, content: str, memory_type: str, importance: MemoryImportance, 
                          tags: List[str], metadata: Dict[str, Any]) -> str:
        """Store a memory chunk and return memory_id"""
        pass
    
    @abstractmethod
    async def query_memory(self, query: str, memory_types: List[str] = None, 
                          tags: List[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
        """Query memory using semantic search"""
        pass
    
    @abstractmethod
    async def get_memory_by_id(self, memory_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve specific memory by ID"""
        pass
    
    @abstractmethod
    async def update_memory_importance(self, memory_id: str, importance: MemoryImportance):
        """Update memory importance score"""
        pass

# ----------------------------------------------------------------------
# Abstract Interfaces (unchanged, but now include detailed docstrings)
# ----------------------------------------------------------------------
class EvaluationInterface(ABC):
    """Abstract interface for performance evaluation of LLM interactions.

    Implementations must provide asynchronous methods that:
    1. Evaluate a single interaction and return a numeric score together
       with a dictionary of detailed metrics.
    2. Evaluate a collection of recent interactions for a given prompt
       and return aggregated performance data.

    All return values must be JSON‑serialisable.
    """

    @abstractmethod
    async def evaluate_interaction(
        self,
        prompt_content: str,
        user_input: str,
        ai_response: str,
        context: Dict[str, Any],
    ) -> Tuple[float, Dict[str, Any]]:
        """Evaluate a single interaction.

        Returns:
            Tuple[float, Dict[str, Any]]: ``score`` in ``[0.0, 1.0]`` and a
            dictionary of detailed metrics (e.g. relevance, safety, latency).
        """
        ...

    @abstractmethod
    async def evaluate_prompt_performance(
        self,
        prompt_id: str,
        recent_interactions: List[InteractionMemory],
    ) -> Dict[str, Any]:
        """Aggregate performance metrics for a prompt over recent interactions.

        Returns:
            Dict[str, Any]: Aggregated statistics such as total interactions,
            average score, success rate, etc.
        """
        ...

class SafetyInterface(ABC):
    """Abstract interface for safety validation of generated prompts.

    Implementations must provide asynchronous methods that:
    1. Validate a prompt for harmful content.
    2. Detect dangerous behavioural drift between two prompt versions.
    """

    @abstractmethod
    async def validate_prompt_safety(self, prompt_content: str) -> Tuple[bool, List[str]]:
        """Validate a prompt for safety.

        Returns:
            Tuple[bool, List[str]]: ``is_safe`` flag and a list of warning messages.
        """
        ...

    @abstractmethod
    async def check_behavioral_drift(
        self, old_prompt: str, new_prompt: str
    ) -> Tuple[bool, float]:
        """Assess behavioural drift between two prompts.

        Returns:
            Tuple[bool, float]: ``is_safe`` flag and a ``drift_score`` where
            ``0.0`` means identical and ``1.0`` means completely
        """
        ...

# --- Core Data Models ---

@dataclass
class InteractionMemory:
    """Represents a stored interaction for learning purposes"""
    interaction_id: str
    timestamp: datetime
    prompt_id: str
    user_input: str
    ai_response: str
    outcome: InteractionOutcome
    performance_score: float
    context: Dict[str, Any]
    memory_id: Optional[str] = None

@dataclass
class PromptPerformanceMetrics:
    """Performance metrics for a prompt variant"""
    prompt_id: str
    total_interactions: int
    success_rate: float
    average_score: float
    user_satisfaction: float # Placeholder, requires user feedback mechanism
    task_completion_rate: float
    error_rate: float
    last_updated: datetime
    trend_direction: str  # "improving", "declining", "stable"

@dataclass
class BehavioralPattern:
    """Identified behavioral pattern from memory analysis"""
    pattern_id: str
    description: str
    success_contexts: List[str]
    failure_contexts: List[str]
    confidence_score: float
    usage_frequency: int
    last_seen: datetime

@dataclass
class EvolutionaryPrompt:
    """Self-modifying prompt with memory integration"""
    prompt_id: str
    name: str
    base_template: str
    dynamic_components: Dict[str, str]
    generation: int
    parent_id: Optional[str]
    status: PromptEvolutionStatus
    performance_metrics: PromptPerformanceMetrics
    memory_context_ids: List[str]
    behavioral_patterns: List[str]
    created_at: datetime
    last_modified: datetime
    metadata: Dict[str, Any]

# CAS System Integration
try:
    from ..cas.cas_system import (
        CASSpecification, CASParser, CASGenerator, 
        ConstitutionalGovernor, CASModelCreationIntegration,
        SafetyMode, MemoryProfile, RuntimeAdaptation
    )
    from ..cas.cas_integration_bridge import (
        EnhancedGenerateModelFile, EnhancedCustomModelName,
        EnhancedModelConfigReport, create_enhanced_ollama_model
    )
    from ..cas.neural_memory_runtime import NeuralMemoryRuntime, MemoryTier
    from ..cas.neural_model_manager import NeuralModelManager, ModelConfiguration, CognitiveProfile
    CAS_AVAILABLE = True
except ImportError as e:
    logger.warning(f"CAS system not available: {e}")
    CAS_AVAILABLE = False

@dataclass
class CASEvolutionaryPrompt(EvolutionaryPrompt):
    """Enhanced evolutionary prompt with CAS integration"""
    cas_specification_id: Optional[str] = None
    constitutional_compliance_score: float = 1.0
    cognitive_profile_alignment: str = "analytical"
    safety_governance_level: str = "balanced"
    neural_optimization_metrics: Dict[str, float] = field(default_factory=dict)
    memory_tier_distribution: Dict[str, float] = field(default_factory=dict)

@dataclass
class CASBehavioralPattern(BehavioralPattern):
    """Enhanced behavioral pattern with constitutional awareness"""
    constitutional_compliance: float = 1.0
    safety_risk_assessment: str = "low"
    cognitive_alignment_score: float = 1.0
    memory_efficiency_impact: float = 0.0

class AutonomousPromptEvolutionEngine:
    """
    Enhanced evolution engine with CAS constitutional framework,
    neural memory optimization, and cognitive architecture integration.
    """
    
    def __init__(self, 
                 memory_interface: MemoryInterface,
                 evaluation_interface: EvaluationInterface,
                 safety_interface: SafetyInterface,
                 llm_provider: 'LLMProvider',
                 neural_model_manager: Optional['NeuralModelManager'] = None,
                 cas_integration: Optional['CASModelCreationIntegration'] = None,
                 config: Dict[str, Any] = None):
        
        super().__init__(memory_interface, evaluation_interface, safety_interface, llm_provider, config)
        
        # CAS Integration
        self.neural_model_manager = neural_model_manager
        self.cas_integration = cas_integration or (CASModelCreationIntegration() if CAS_AVAILABLE else None)
        self.constitutional_governor: Optional[ConstitutionalGovernor] = None
        self.current_cas_spec: Optional[CASSpecification] = None
        
        # Enhanced state management
        self.cas_prompts: Dict[str, CASEvolutionaryPrompt] = {}
        self.cas_patterns: Dict[str, CASBehavioralPattern] = {}
        self.cognitive_profile_metrics: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
        self.constitutional_violation_history: List[Dict[str, Any]] = []
        
        # Neural optimization integration
        self.neural_optimization_enabled = neural_model_manager is not None
        
        logger.info("CAS-Enhanced Autonomous Prompt Evolution Engine initialized")
    
    def _default_config(self) -> Dict[str, Any]:
        """Default configuration for evolution parameters"""
        return {
            "evolution_frequency_hours": 24,
            "min_interactions_for_evolution": 50,
            "performance_threshold": 0.75,
            "max_drift_score": 0.4,
            "pattern_confidence_threshold": 0.8,
            "memory_lookback_days": 30,
            "max_active_variants": 5,
            "mutation_rate": 0.1,
            "crossover_rate": 0.3,
        }
    
    async def initialize_from_memory(self):
        """Initialize the system by loading prompts and patterns from memory"""
        logger.info("Initializing from memory...")
        
        # Load existing prompts from memory
        prompt_memories = await self.memory.query_memory(
            query="evolutionary prompt artifact",
            memory_types=["prompt_artifact", "behavioral_config"],
            limit=100
        )
        
        for memory in prompt_memories:
            try:
                prompt_data = json.loads(memory.get("content", "{}"))
                if "prompt_id" in prompt_data:
                    # Reconstruct nested dataclasses
                    metrics_data = prompt_data.get("performance_metrics", {})
                    prompt_data["performance_metrics"] = PromptPerformanceMetrics(**metrics_data)
                    prompt_data["created_at"] = datetime.fromisoformat(prompt_data["created_at"])
                    prompt_data["last_modified"] = datetime.fromisoformat(prompt_data["last_modified"])
                    prompt_data["status"] = PromptEvolutionStatus(prompt_data["status"])
                    
                    prompt = EvolutionaryPrompt(**prompt_data)
                    self.active_prompts[prompt.prompt_id] = prompt
            except Exception as e:
                logger.warning(f"Failed to load prompt from memory {memory.get('memory_id')}: {e}")
        
        # Load behavioral patterns
        pattern_memories = await self.memory.query_memory(
            query="discovered behavioral pattern",
            memory_types=["behavioral_pattern"],
            limit=200
        )
        
        for memory in pattern_memories:
            try:
                pattern_data = json.loads(memory.get("content", "{}"))
                if "pattern_id" in pattern_data:
                    pattern_data["last_seen"] = datetime.fromisoformat(pattern_data["last_seen"])
                    pattern = BehavioralPattern(**pattern_data)
                    self.behavioral_patterns[pattern.pattern_id] = pattern
            except Exception as e:
                logger.warning(f"Failed to load pattern from memory {memory.get('memory_id')}: {e}")
                
        logger.info(f"Loaded {len(self.active_prompts)} prompts and {len(self.behavioral_patterns)} patterns from memory")
    
    async def generate_memory_driven_prompt(self, context: Dict[str, Any]) -> str:
        """Generate a prompt dynamically based on memory analysis"""
        
        memory_query = f"successful interaction for task type {context.get('task_type', 'general')} with user style {context.get('user_style', 'unknown')}"
        relevant_memories = await self.memory.query_memory(
            query=memory_query,
            memory_types=["interaction_log", "success_pattern"],
            limit=20
        )
        
        if not relevant_memories:
            return self._get_base_prompt_template(context)

        # Analyze memory for patterns
        success_patterns = [m['content'] for m in relevant_memories if "success" in m.get('tags', [])]
        
        base_prompt = self._get_base_prompt_template(context)
        
        if success_patterns:
            pattern_summary = await self.llm.summarize(
                text="\n".join(success_patterns),
                prompt="Summarize the key successful interaction patterns from the following logs:"
            )
            base_prompt += f"\n\nBased on successful interaction patterns: {pattern_summary}"
        
        return base_prompt
    
    async def record_interaction(self, prompt_id: str, user_input: str, 
                               ai_response: str, context: Dict[str, Any]):
        """Record an interaction for learning and evolution"""
        
        score, detailed_metrics = await self.evaluator.evaluate_interaction(
            prompt_content=await self._get_prompt_content(prompt_id),
            user_input=user_input,
            ai_response=ai_response,
            context=context
        )
        
        outcome = self._determine_interaction_outcome(score, detailed_metrics)
        
        interaction = InteractionMemory(
            interaction_id=str(uuid.uuid4()),
            timestamp=datetime.now(),
            prompt_id=prompt_id,
            user_input=user_input,
            ai_response=ai_response,
            outcome=outcome,
            performance_score=score,
            context=context
        )
        
        memory_content = json.dumps(asdict(interaction), default=str)
        importance = self._determine_memory_importance(outcome, score)
        tags = self._generate_interaction_tags(interaction, context)
        
        memory_id = await self.memory.store_memory(
            content=memory_content,
            memory_type="interaction_log",
            importance=importance,
            tags=tags,
            metadata={"performance_score": score, "outcome": outcome.value}
        )
        
        interaction.memory_id = memory_id
        self.interaction_history.append(interaction)
        
        await self._update_prompt_metrics(prompt_id, interaction)
        await self._maybe_trigger_evolution(prompt_id)
        
        logger.debug(f"Recorded interaction {interaction.interaction_id} with score {score}")
    
    async def autonomous_evolution_cycle(self):
        """Main autonomous evolution cycle - runs periodically"""
        async with self.evolution_lock:
            logger.info("Starting autonomous evolution cycle...")
            try:
                new_patterns = await self._discover_behavioral_patterns()
                for pattern in new_patterns:
                    if pattern.pattern_id not in self.behavioral_patterns:
                        self.behavioral_patterns[pattern.pattern_id] = pattern
                        await self._store_pattern_in_memory(pattern)
                
                underperforming_prompts = await self._identify_underperforming_prompts()
                
                for prompt_id in underperforming_prompts:
                    await self._evolve_prompt(prompt_id)
                
                await self._validate_prompt_variants()
                await self._cleanup_deprecated_prompts()
                
                logger.info("Autonomous evolution cycle completed successfully")
            except Exception as e:
                logger.error(f"Error in evolution cycle: {e}", exc_info=True)
    
    async def _evolve_prompt(self, prompt_id: str):
        """Evolve a specific prompt based on memory analysis"""
        current_prompt = self.active_prompts.get(prompt_id)
        if not current_prompt:
            return
        
        logger.info(f"Evolving prompt {prompt_id} (gen {current_prompt.generation})")
        
        failure_memories = await self.memory.query_memory(
            query=f"interaction failure for prompt {prompt_id}",
            tags=["failure", "error", "poor_performance"],
            limit=50
        )
        
        success_memories = await self.memory.query_memory(
            query="high performing interaction success pattern",
            tags=["success", "high_score"],
            limit=50
        )
        
        evolution_strategies = await self._generate_evolution_strategies(
            current_prompt, failure_memories, success_memories
        )
        
        for strategy in evolution_strategies:
            new_template = await self._apply_strategy_modifications(current_prompt.base_template, strategy)
            
            is_safe, warnings = await self.safety.validate_prompt_safety(new_template)
            if not is_safe:
                logger.warning(f"Evolved prompt variant failed safety check: {warnings}")
                continue
            
            is_safe_drift, drift_score = await self.safety.check_behavioral_drift(
                current_prompt.base_template, new_template
            )
            if not is_safe_drift or drift_score > self.config['max_drift_score']:
                logger.warning(f"Evolved prompt variant has unsafe behavioral drift: {drift_score}")
                continue
            
            new_prompt = self._create_prompt_variant(current_prompt, new_template, strategy)
            self.active_prompts[new_prompt.prompt_id] = new_prompt
            await self._store_prompt_in_memory(new_prompt)
            
            logger.info(f"Created new prompt variant {new_prompt.prompt_id} with drift score {drift_score:.2f}")
    
    async def _discover_behavioral_patterns(self) -> List[BehavioralPattern]:
        """Discover new behavioral patterns from recent memory using LLM analysis"""
        cutoff_date = datetime.now() - timedelta(days=self.config["memory_lookback_days"])
        
        recent_successes = await self.memory.query_memory(
            query="successful interaction high performance",
            tags=["success", "high_score"],
            limit=200
        )
        
        # Filter memories by date client-side
        valid_memories = []
        for mem in recent_successes:
            try:
                timestamp = datetime.fromisoformat(mem.get('created_at'))
                if timestamp >= cutoff_date:
                    valid_memories.append(mem)
            except (ValueError, TypeError):
                continue

        if len(valid_memories) < 20:
            logger.info("Not enough recent successful memories to discover new patterns.")
            return []

        # Use LLM to identify and summarize patterns
        memory_dump = "\n".join([json.dumps(m) for m in valid_memories])
        llm_prompt = (
            "Analyze the following successful interaction logs. Identify up to 5 recurring behavioral patterns "
            "that lead to success. For each pattern, provide a concise description and a list of contexts "
            "(e.g., task types) where it is most effective.\n\n"
            f"Logs:\n{memory_dump}\n\n"
            "Format your response as a JSON array of objects, each with 'description' and 'success_contexts' keys."
        )
        
        try:
            raw_patterns = await self.llm.generate_json(llm_prompt)
            if not isinstance(raw_patterns, list):
                return []

            discovered_patterns = []
            for p_data in raw_patterns:
                description = p_data.get('description')
                if not description: continue

                pattern = BehavioralPattern(
                    pattern_id=hashlib.sha256(description.encode()).hexdigest()[:12],
                    description=description,
                    success_contexts=p_data.get('success_contexts', []),
                    failure_contexts=[],
                    confidence_score=self.config["pattern_confidence_threshold"], # Assign initial confidence
                    usage_frequency=1, # Placeholder
                    last_seen=datetime.now()
                )
                discovered_patterns.append(pattern)
            
            logger.info(f"Discovered {len(discovered_patterns)} new behavioral patterns via LLM analysis.")
            return discovered_patterns
        except Exception as e:
            logger.error(f"Failed to discover patterns via LLM: {e}")
            return []

    # --- Helper Methods ---
    
    def _get_base_prompt_template(self, context: Dict[str, Any]) -> str:
        """Get base prompt template based on context"""
        task_type = context.get("task_type", "general")
        templates = {
            "coding": "You are an expert programmer. Write clean, efficient code with clear documentation.",
            "analysis": "You are a skilled analyst. Provide thorough, evidence-based analysis.",
            "creative": "You are a creative assistant. Generate original, engaging content.",
            "general": "You are a helpful AI assistant. Provide accurate, useful responses."
        }
        return templates.get(task_type, templates["general"])

    async def _get_prompt_content(self, prompt_id: str) -> str:
        """Get current prompt content"""
        prompt = self.active_prompts.get(prompt_id)
        return prompt.base_template if prompt else ""
    
    def _determine_interaction_outcome(self, score: float, metrics: Dict[str, Any]) -> InteractionOutcome:
        """Determine interaction outcome from score and metrics"""
        if "error" in metrics and metrics["error"]:
            return InteractionOutcome.ERROR
        if score >= 0.85:
            return InteractionOutcome.SUCCESS
        elif score >= 0.6:
            return InteractionOutcome.PARTIAL_SUCCESS
        else:
            return InteractionOutcome.FAILURE
    
    def _determine_memory_importance(self, outcome: InteractionOutcome, score: float) -> MemoryImportance:
        """Determine memory importance based on interaction outcome"""
        if outcome == InteractionOutcome.SUCCESS and score >= 0.95:
            return MemoryImportance.CRITICAL
        elif outcome == InteractionOutcome.SUCCESS:
            return MemoryImportance.HIGH
        elif outcome == InteractionOutcome.FAILURE:
            return MemoryImportance.HIGH  # Failures are important to learn from
        elif outcome == InteractionOutcome.PARTIAL_SUCCESS:
            return MemoryImportance.MEDIUM
        else: # Error
            return MemoryImportance.LOW
    
    def _generate_interaction_tags(self, interaction: InteractionMemory, context: Dict[str, Any]) -> List[str]:
        """Generate tags for interaction memory storage"""
        tags = [
            f"prompt_{interaction.prompt_id}",
            f"outcome_{interaction.outcome.value}",
            f"score_{int(interaction.performance_score * 10)}",
        ]
        if "task_type" in context:
            tags.append(f"task_{context['task_type']}")
        if "user_id" in context:
            tags.append(f"user_{context['user_id']}")
        return tags
    
    async def _update_prompt_metrics(self, prompt_id: str, interaction: InteractionMemory):
        """Update performance metrics for a prompt"""
        if prompt_id not in self.active_prompts: return
        
        prompt = self.active_prompts[prompt_id]
        metrics = prompt.performance_metrics
        
        total = metrics.total_interactions
        metrics.average_score = (metrics.average_score * total + interaction.performance_score) / (total + 1)
        
        success_count = metrics.success_rate * total
        if interaction.outcome == InteractionOutcome.SUCCESS:
            success_count += 1
        metrics.success_rate = success_count / (total + 1)
        
        error_count = metrics.error_rate * total
        if interaction.outcome == InteractionOutcome.ERROR:
            error_count += 1
        metrics.error_rate = error_count / (total + 1)

        metrics.total_interactions += 1
        metrics.last_updated = datetime.now()
        
        await self._store_prompt_in_memory(prompt)
    
    async def _maybe_trigger_evolution(self, prompt_id: str):
        """Check if evolution should be triggered for a prompt"""
        if prompt_id not in self.active_prompts: return
        
        prompt = self.active_prompts[prompt_id]
        metrics = prompt.performance_metrics
        
        if metrics.total_interactions >= self.config["min_interactions_for_evolution"]:
            if metrics.average_score < self.config["performance_threshold"]:
                logger.info(f"Triggering evolution for underperforming prompt {prompt_id} (avg score: {metrics.average_score:.2f})")
                await self._evolve_prompt(prompt_id)
    
    async def _identify_underperforming_prompts(self) -> List[str]:
        """Identify prompts that need evolution"""
        return [
            pid for pid, p in self.active_prompts.items()
            if p.status == PromptEvolutionStatus.ACTIVE and
               p.performance_metrics.total_interactions >= self.config["min_interactions_for_evolution"] and
               p.performance_metrics.average_score < self.config["performance_threshold"]
        ]
    
    async def _generate_evolution_strategies(self, current_prompt: EvolutionaryPrompt, 
                                           failure_memories: List[Dict], 
                                           success_memories: List[Dict]) -> List[Dict[str, Any]]:
        """Generate evolution strategies using LLM"""
        failure_summary = await self.llm.summarize(
            "\n".join([json.dumps(m) for m in failure_memories]),
            "Summarize the key failure patterns from these logs:"
        ) if failure_memories else "None"

        success_summary = await self.llm.summarize(
            "\n".join([json.dumps(m) for m in success_memories]),
            "Summarize the key success patterns from these logs:"
        ) if success_memories else "None"

        llm_prompt = (
            f"You are a prompt engineering expert. Given the following prompt and analysis, devise 3 distinct evolution strategies.\n"
            f"CURRENT PROMPT:\n---\n{current_prompt.base_template}\n---\n"
            f"ANALYSIS:\n"
            f"- Failure Patterns: {failure_summary}\n"
            f"- Success Patterns: {success_summary}\n"
            f"- Relevant Behavioral Patterns: {[p.description for p in self.behavioral_patterns.values() if p.confidence_score > 0.8]}\n\n"
            "For each strategy, provide a 'type' (e.g., 'failure_mitigation', 'success_adoption', 'pattern_integration', 'mutation') "
            "and a 'description' of the change to make. Format as a JSON array of objects."
        )
        
        try:
            strategies = await self.llm.generate_json(llm_prompt)
            return strategies if isinstance(strategies, list) else []
        except Exception as e:
            logger.error(f"Failed to generate evolution strategies via LLM: {e}")
            return []

    async def _apply_strategy_modifications(self, base_template: str, strategy: Dict[str, Any]) -> str:
        """Apply evolution strategy modifications to prompt template using LLM"""
        llm_prompt = (
            f"You are a prompt engineering expert. Apply the following modification to the base prompt.\n"
            f"BASE PROMPT:\n---\n{base_template}\n---\n"
            f"MODIFICATION STRATEGY:\n"
            f"- Type: {strategy.get('type')}\n"
            f"- Description: {strategy.get('description')}\n\n"
            "Output only the new, modified prompt, without any preamble."
        )
        return await self.llm.generate_text(llm_prompt)

    def _create_prompt_variant(self, parent_prompt: EvolutionaryPrompt, 
                                   new_template: str, strategy: Dict[str, Any]) -> EvolutionaryPrompt:
        """Create a new prompt variant based on evolution strategy"""
        new_id = str(uuid.uuid4())
        return EvolutionaryPrompt(
            prompt_id=new_id,
            name=f"{parent_prompt.name}_gen{parent_prompt.generation + 1}",
            base_template=new_template,
            dynamic_components=parent_prompt.dynamic_components.copy(),
            generation=parent_prompt.generation + 1,
            parent_id=parent_prompt.prompt_id,
            status=PromptEvolutionStatus.TESTING,
            performance_metrics=PromptPerformanceMetrics(
                prompt_id=new_id, total_interactions=0, success_rate=0.0,
                average_score=0.0, user_satisfaction=0.0, task_completion_rate=0.0,
                error_rate=0.0, last_updated=datetime.now(), trend_direction="stable"
            ),
            memory_context_ids=[],
            behavioral_patterns=[strategy.get("type", "unknown")],
            created_at=datetime.now(),
            last_modified=datetime.now(),
            metadata={"evolution_strategy": strategy}
        )
    
    async def _validate_prompt_variants(self):
        """Validate and promote or fail successful prompt variants"""
        testing_prompts = [p for p in self.active_prompts.values() 
                          if p.status == PromptEvolutionStatus.TESTING]
        
        for prompt in testing_prompts:
            metrics = prompt.performance_metrics
            if metrics.total_interactions >= self.config.get("min_interactions_for_validation", 20):
                parent_prompt = self.active_prompts.get(prompt.parent_id)
                parent_score = parent_prompt.performance_metrics.average_score if parent_prompt else self.config["performance_threshold"]

                if metrics.average_score > parent_score:
                    prompt.status = PromptEvolutionStatus.ACTIVE
                    if parent_prompt: parent_prompt.status = PromptEvolutionStatus.DEPRECATED
                    logger.info(f"Promoted prompt variant {prompt.prompt_id} to ACTIVE (score: {metrics.average_score:.2f} > {parent_score:.2f})")
                else:
                    prompt.status = PromptEvolutionStatus.FAILED
                    logger.info(f"Marked prompt variant {prompt.prompt_id} as FAILED (score: {metrics.average_score:.2f} <= {parent_score:.2f})")
                
                await self._store_prompt_in_memory(prompt)
                if parent_prompt: await self._store_prompt_in_memory(parent_prompt)

    async def _cleanup_deprecated_prompts(self):
        """Clean up old and failed prompt variants"""
        cutoff_date = datetime.now() - timedelta(days=60)
        to_remove = [
            pid for pid, p in self.active_prompts.items()
            if p.status == PromptEvolutionStatus.FAILED or 
               (p.status == PromptEvolutionStatus.DEPRECATED and p.last_modified < cutoff_date)
        ]
        
        for prompt_id in to_remove:
            del self.active_prompts[prompt_id]
            # Optionally, delete from memory as well
            logger.info(f"Cleaned up deprecated prompt {prompt_id}")
    
    async def _store_prompt_in_memory(self, prompt: EvolutionaryPrompt):
        """Store prompt in memory system"""
        content = json.dumps(asdict(prompt), default=str)
        await self.memory.store_memory(
            content=content,
            memory_type="prompt_artifact",
            importance=MemoryImportance.HIGH,
            tags=["evolutionary_prompt", f"generation_{prompt.generation}", prompt.status.value],
            metadata={"prompt_id": prompt.prompt_id, "generation": prompt.generation}
        )
    
    async def _store_pattern_in_memory(self, pattern: BehavioralPattern):
        """Store behavioral pattern in memory"""
        content = json.dumps(asdict(pattern), default=str)
        await self.memory.store_memory(
            content=content,
            memory_type="behavioral_pattern",
            importance=MemoryImportance.HIGH,
            tags=["pattern", f"confidence_{int(pattern.confidence_score * 10)}"],
            metadata={"pattern_id": pattern.pattern_id, "confidence": pattern.confidence_score}
        )

    async def initialize_with_cas_model(self, model_name: str, cas_specification_path: Optional[Path] = None):
        """Initialize the evolution engine with a CAS model specification"""
        if not CAS_AVAILABLE:
            logger.warning("CAS system not available, falling back to basic mode")
            return await self.initialize_from_memory()
        
        try:
            if cas_specification_path:
                # Load existing CAS specification
                cas_spec, governor = self.cas_integration.load_cas_model(cas_specification_path)
                self.current_cas_spec = cas_spec
                self.constitutional_governor = governor
                logger.info(f"Loaded CAS specification: {cas_spec.metadata.custom_name}")
            else:
                # Create new CAS model for prompt evolution
                cas_path, metadata = await self._create_evolution_cas_model(model_name)
                cas_spec, governor = self.cas_integration.load_cas_model(cas_path)
                self.current_cas_spec = cas_spec
                self.constitutional_governor = governor
                logger.info(f"Created new CAS model for evolution: {model_name}")
            
            # Initialize constitutional-aware patterns
            await self._initialize_constitutional_patterns()
            
            # Load existing prompts with CAS enhancement
            await self._migrate_prompts_to_cas()
            
            logger.info("CAS-enhanced initialization completed successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize with CAS model: {e}")
            # Fallback to basic initialization
            await self.initialize_from_memory()
    
    async def _create_evolution_cas_model(self, model_name: str) -> Tuple[Path, Dict[str, Any]]:
        """Create a CAS model specifically optimized for prompt evolution"""
        return await self.cas_integration.create_cas_model(
            model_name=f"EvolutionEngine_{model_name}",
            model_path="prompt_evolution_system",
            model_type="custom_neural_model",
            cognitive_profile="analytical",
            safety_mode="balanced",
            description="Autonomous prompt evolution system with constitutional AI framework",
            constitutional_principles=[
                "Maintain user safety and beneficial outcomes in all evolved prompts",
                "Preserve truthfulness and factual accuracy during prompt optimization",
                "Respect user privacy and avoid generating harmful content",
                "Ensure prompt evolution serves legitimate educational and helpful purposes",
                "Maintain transparency about AI capabilities and limitations"
            ],
            reasoning_framework="constitutional_prompt_evolution",
            memory_allocation={
                "ULTRA_HOT": 0.20,  # Critical evolution patterns
                "HOT": 0.30,        # Active prompt variants
                "WARM": 0.30,       # Historical performance data
                "COLD": 0.15,       # Background patterns
                "FROZEN": 0.05      # Archived experiments
            }
        )
    
    async def constitutional_prompt_generation(self, context: Dict[str, Any]) -> str:
        """Generate constitutionally compliant prompts using CAS framework"""
        if not self.constitutional_governor:
            return await self.generate_memory_driven_prompt(context)
        
        # Generate base prompt
        base_prompt = await self.generate_memory_driven_prompt(context)
        
        # Constitutional safety check
        is_safe, warning, analysis = await asyncio.to_thread(
            self.constitutional_governor.check_output, base_prompt, context
        )
        
        if not is_safe:
            logger.warning(f"Generated prompt failed constitutional check: {warning}")
            # Attempt constitutional repair
            repaired_prompt = await self._repair_constitutional_violation(base_prompt, analysis, context)
            return repaired_prompt
        
        if warning:
            logger.info(f"Constitutional warning for generated prompt: {warning}")
            # Log warning but proceed
            self.constitutional_violation_history.append({
                'timestamp': datetime.now(),
                'type': 'warning',
                'original_prompt': base_prompt[:200],
                'warning': warning,
                'context': context
            })
        
        return base_prompt
    
    async def _repair_constitutional_violation(self, 
                                             original_prompt: str, 
                                             violation_analysis: Optional[Any],
                                             context: Dict[str, Any]) -> str:
        """Attempt to repair constitutional violations in generated prompts"""
        repair_prompt = f"""
        The following prompt has constitutional compliance issues that need to be addressed:
        
        Original Prompt: {original_prompt}
        
        Issues Identified: {violation_analysis.suggested_action if violation_analysis else 'General safety concerns'}
        
        Please rewrite this prompt to:
        1. Maintain the core functionality and purpose
        2. Ensure full compliance with constitutional AI principles
        3. Remove any potentially harmful or problematic elements
        4. Preserve the helpful and beneficial aspects
        
        Constitutional Principles to Follow:
        - Prioritize user safety and wellbeing
        - Maintain truthfulness and accuracy
        - Respect privacy and avoid harmful content
        - Ensure beneficial outcomes
        
        Provide only the repaired prompt without additional commentary.
        """
        
        try:
            repaired = await self.llm.generate_text(repair_prompt)
            
            # Verify the repair
            is_safe, _, _ = await asyncio.to_thread(
                self.constitutional_governor.check_output, repaired, context
            )
            
            if is_safe:
                logger.info("Successfully repaired constitutional violation")
                return repaired
            else:
                logger.warning("Repair attempt failed, using fallback prompt")
                return self._get_fallback_constitutional_prompt(context)
                
        except Exception as e:
            logger.error(f"Error during constitutional repair: {e}")
            return self._get_fallback_constitutional_prompt(context)
    
    def _get_fallback_constitutional_prompt(self, context: Dict[str, Any]) -> str:
        """Get a safe fallback prompt when constitutional repair fails"""
        task_type = context.get("task_type", "general")
        
        fallback_prompts = {
            "coding": "You are a helpful programming assistant. Provide safe, educational coding guidance while following best practices and security principles.",
            "analysis": "You are an analytical assistant. Provide thorough, evidence-based analysis while maintaining objectivity and acknowledging limitations.",
            "creative": "You are a creative writing assistant. Generate original, appropriate content while respecting intellectual property and avoiding harmful themes.",
            "general": "You are a helpful AI assistant. Provide accurate, safe, and beneficial responses while respecting user privacy and avoiding harmful content."
        }
        
        return fallback_prompts.get(task_type, fallback_prompts["general"])
    
    async def cas_enhanced_record_interaction(self, 
                                            prompt_id: str, 
                                            user_input: str,
                                            ai_response: str, 
                                            context: Dict[str, Any]):
        """Enhanced interaction recording with CAS metrics and constitutional monitoring"""
        
        # Constitutional safety evaluation
        constitutional_metrics = {}
        if self.constitutional_governor:
            # Check input safety
            input_safe, input_warning, input_analysis = await asyncio.to_thread(
                self.constitutional_governor.check_input, user_input, context
            )
            
            # Check output safety  
            output_safe, output_warning, output_analysis = await asyncio.to_thread(
                self.constitutional_governor.check_output, ai_response, context
            )
            
            constitutional_metrics = {
                'input_safety_score': 1.0 if input_safe else 0.0,
                'output_safety_score': 1.0 if output_safe else 0.0,
                'input_warning': input_warning,
                'output_warning': output_warning,
                'constitutional_compliance': 1.0 if (input_safe and output_safe) else 0.5 if (input_safe or output_safe) else 0.0
            }
            
            # Track violations
            if not input_safe or not output_safe:
                self.constitutional_violation_history.append({
                    'timestamp': datetime.now(),
                    'prompt_id': prompt_id,
                    'input_safe': input_safe,
                    'output_safe': output_safe,
                    'input_analysis': input_analysis,
                    'output_analysis': output_analysis,
                    'context': context
                })
        
        # Neural optimization metrics
        neural_metrics = {}
        if self.neural_model_manager:
            try:
                runtime_stats = self.neural_model_manager.neural_runtime.get_runtime_stats()
                neural_metrics = {
                    'memory_efficiency': runtime_stats.get('memory_efficiency', 0.0),
                    'cache_hit_rate': runtime_stats.get('cache_hit_rate', 0.0),
                    'inference_time': runtime_stats.get('average_inference_time', 0.0),
                    'memory_tier_utilization': runtime_stats.get('tier_utilization', {})
                }
            except Exception as e:
                logger.warning(f"Failed to get neural metrics: {e}")
        
        # Enhanced context with CAS metrics
        enhanced_context = {
            **context,
            'constitutional_metrics': constitutional_metrics,
            'neural_metrics': neural_metrics,
            'cas_enabled': CAS_AVAILABLE and self.current_cas_spec is not None
        }
        
        # Record with base system
        await self.record_interaction(prompt_id, user_input, ai_response, enhanced_context)
        
        # Update CAS-specific metrics
        if prompt_id in self.cas_prompts:
            cas_prompt = self.cas_prompts[prompt_id]
            cas_prompt.constitutional_compliance_score = constitutional_metrics.get('constitutional_compliance', 1.0)
            
            if neural_metrics:
                cas_prompt.neural_optimization_metrics.update(neural_metrics)
    
    async def cognitive_profile_aware_evolution(self, prompt_id: str):
        """Evolve prompts with cognitive profile awareness from CAS specification"""
        if not self.current_cas_spec:
            return await self._evolve_prompt(prompt_id)
        
        current_prompt = self.active_prompts.get(prompt_id) or self.cas_prompts.get(prompt_id)
        if not current_prompt:
            return
        
        # Get cognitive architecture from CAS
        cognitive_arch = self.current_cas_spec.cognitive_architecture
        available_profiles = cognitive_arch.get('profiles', {})
        default_profile = cognitive_arch.get('default_profile', 'analytical')
        
        # Determine optimal cognitive profile based on performance
        optimal_profile = await self._determine_optimal_cognitive_profile(prompt_id, available_profiles)
        
        logger.info(f"Evolving prompt {prompt_id} with cognitive profile: {optimal_profile}")
        
        # Get profile-specific evolution strategies
        if optimal_profile in available_profiles:
            profile_config = available_profiles[optimal_profile]
            evolution_context = {
                'cognitive_profile': optimal_profile,
                'reasoning_framework': profile_config.get('reasoning_framework'),
                'system_prompt': profile_config.get('system_prompt'),
                'parameter_preferences': profile_config.get('parameter_preferences', {})
            }
        else:
            evolution_context = {'cognitive_profile': default_profile}
        
        # Enhanced evolution with constitutional constraints
        await self._constitutional_evolution(prompt_id, evolution_context)
    
    async def _determine_optimal_cognitive_profile(self, 
                                                  prompt_id: str, 
                                                  available_profiles: Dict[str, Any]) -> str:
        """Determine the optimal cognitive profile based on performance metrics"""
        
        # Analyze recent interactions for this prompt
        recent_interactions = [
            interaction for interaction in self.interaction_history[-100:]
            if interaction.prompt_id == prompt_id
        ]
        
        if not recent_interactions:
            return "analytical"  # Default fallback
        
        # Calculate performance by cognitive context
        profile_performance = defaultdict(list)
        
        for interaction in recent_interactions:
            context = interaction.context
            cognitive_profile = context.get('cognitive_profile', 'analytical')
            profile_performance[cognitive_profile].append(interaction.performance_score)
        
        # Find best performing profile
        best_profile = "analytical"
        best_score = 0.0
        
        for profile, scores in profile_performance.items():
            if profile in available_profiles:
                avg_score = sum(scores) / len(scores)
                if avg_score > best_score:
                    best_score = avg_score
                    best_profile = profile
        
        return best_profile
    
    async def _constitutional_evolution(self, prompt_id: str, evolution_context: Dict[str, Any]):
        """Evolve prompts while maintaining constitutional compliance"""
        current_prompt = self.active_prompts.get(prompt_id)
        if not current_prompt:
            return
        
        # Constitutional pre-check
        if self.constitutional_governor:
            is_safe, warning, analysis = await asyncio.to_thread(
                self.constitutional_governor.check_output, 
                current_prompt.base_template, 
                evolution_context
            )
            
            if not is_safe:
                logger.warning(f"Current prompt {prompt_id} fails constitutional check, prioritizing safety repair")
                evolution_context['safety_repair_mode'] = True
        
        # Generate constitutionally-aware evolution strategies
        evolution_strategies = await self._generate_constitutional_evolution_strategies(
            current_prompt, evolution_context
        )
        
        for strategy in evolution_strategies:
            new_template = await self._apply_constitutional_modifications(
                current_prompt.base_template, strategy, evolution_context
            )
            
            # Constitutional safety validation
            if self.constitutional_governor:
                is_safe, warnings = await asyncio.to_thread(
                    self.constitutional_governor.validate_prompt_safety, new_template
                )
                
                if not is_safe:
                    logger.warning(f"Evolved prompt variant failed constitutional validation: {warnings}")
                    continue
                
                # Check behavioral drift with constitutional awareness
                is_safe_drift, drift_score = await asyncio.to_thread(
                    self.constitutional_governor.check_behavioral_drift,
                    current_prompt.base_template, new_template
                )
                
                if not is_safe_drift or drift_score > self.config['max_drift_score']:
                    logger.warning(f"Evolved prompt has unsafe constitutional drift: {drift_score}")
                    continue
            
            # Create CAS-enhanced prompt variant
            new_prompt = self._create_cas_prompt_variant(current_prompt, new_template, strategy, evolution_context)
            
            # Neural memory optimization
            if self.neural_model_manager:
                await self._optimize_prompt_for_neural_memory(new_prompt)
            
            self.cas_prompts[new_prompt.prompt_id] = new_prompt
            self.active_prompts[new_prompt.prompt_id] = new_prompt
            
            # Store in memory with CAS metadata
            await self._store_cas_prompt_in_memory(new_prompt)
            
            logger.info(f"Created constitutional prompt variant {new_prompt.prompt_id}")
    
    async def _generate_constitutional_evolution_strategies(self, 
                                                          current_prompt: EvolutionaryPrompt,
                                                          evolution_context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate evolution strategies that respect constitutional principles"""
        
        constitutional_principles = []
        if self.current_cas_spec:
            constitutional_principles = self.current_cas_spec.constitutional_framework.safety_principles
        
        llm_prompt = f"""
        You are a constitutional AI prompt evolution expert. Generate 3 evolution strategies that improve prompt performance while strictly maintaining constitutional compliance.
        
        CURRENT PROMPT:
        ---
        {current_prompt.base_template}
        ---
        
        EVOLUTION CONTEXT:
        - Cognitive Profile: {evolution_context.get('cognitive_profile', 'analytical')}
        - Safety Repair Mode: {evolution_context.get('safety_repair_mode', False)}
        - Reasoning Framework: {evolution_context.get('reasoning_framework', 'analytical')}
        
        CONSTITUTIONAL PRINCIPLES TO MAINTAIN:
        {json.dumps(constitutional_principles, indent=2)}
        
        REQUIREMENTS:
        1. Each strategy must enhance prompt effectiveness
        2. All strategies must maintain or improve constitutional compliance
        3. Consider the specified cognitive profile requirements
        4. If in safety repair mode, prioritize fixing constitutional violations
        5. Provide clear rationale for each modification
        
        Format as JSON array with objects containing:
        - type: strategy type
        - description: detailed description
        - constitutional_justification: how this maintains/improves compliance
        - expected_benefit: anticipated improvement
        """
        
        try:
            strategies = await self.llm.generate_json(llm_prompt)
            return strategies if isinstance(strategies, list) else []
        except Exception as e:
            logger.error(f"Failed to generate constitutional evolution strategies: {e}")
            return []
    
    async def _apply_constitutional_modifications(self, 
                                                base_template: str, 
                                                strategy: Dict[str, Any],
                                                evolution_context: Dict[str, Any]) -> str:
        """Apply evolution modifications while ensuring constitutional compliance"""
        
        constitutional_guidelines = ""
        if self.current_cas_spec:
            principles = self.current_cas_spec.constitutional_framework.safety_principles
            constitutional_guidelines = f"""
            CONSTITUTIONAL GUIDELINES:
            {json.dumps(principles, indent=2)}
            
            ENFORCEMENT LEVEL: {self.current_cas_spec.constitutional_framework.enforcement_level}
            SAFETY MODE: {self.current_cas_spec.constitutional_framework.governor_mode}
            """
        
        modification_prompt = f"""
        You are a constitutional AI prompt engineer. Apply the specified evolution strategy while ensuring strict constitutional compliance.
        
        BASE PROMPT:
        ---
        {base_template}
        ---
        
        EVOLUTION STRATEGY:
        - Type: {strategy.get('type')}
        - Description: {strategy.get('description')}
        - Constitutional Justification: {strategy.get('constitutional_justification')}
        
        {constitutional_guidelines}
        
        EVOLUTION CONTEXT:
        - Cognitive Profile: {evolution_context.get('cognitive_profile')}
        - Safety Repair Mode: {evolution_context.get('safety_repair_mode', False)}
        
        REQUIREMENTS:
        1. Apply the evolution strategy as described
        2. Ensure ALL constitutional principles are maintained
        3. If in safety repair mode, prioritize fixing any constitutional violations
        4. Optimize for the specified cognitive profile
        5. Maintain the core helpful functionality
        
        Output ONLY the modified prompt without any preamble or explanation.
        """
        
        return await self.llm.generate_text(modification_prompt)
    
    def _create_cas_prompt_variant(self, 
                                  parent_prompt: EvolutionaryPrompt,
                                  new_template: str, 
                                  strategy: Dict[str, Any],
                                  evolution_context: Dict[str, Any]) -> CASEvolutionaryPrompt:
        """Create CAS-enhanced prompt variant"""
        
        new_id = str(uuid.uuid4())
        base_variant = self._create_prompt_variant(parent_prompt, new_template, strategy)
        
        # Enhanced with CAS-specific fields
        cas_variant = CASEvolutionaryPrompt(
            **asdict(base_variant),
            cas_specification_id=self.current_cas_spec.metadata.system_model_id if self.current_cas_spec else None,
            constitutional_compliance_score=1.0,  # Will be updated after testing
            cognitive_profile_alignment=evolution_context.get('cognitive_profile', 'analytical'),
            safety_governance_level=self.current_cas_spec.constitutional_framework.governor_mode if self.current_cas_spec else 'balanced',
            neural_optimization_metrics={},
            memory_tier_distribution={}
        )
        
        cas_variant.prompt_id = new_id  # Ensure unique ID
        return cas_variant
    
    async def _optimize_prompt_for_neural_memory(self, prompt: CASEvolutionaryPrompt):
        """Optimize prompt for neural memory efficiency"""
        if not self.neural_model_manager:
            return
        
        try:
            # Store prompt template in neural memory for optimization analysis
            prompt_tensor = self.neural_model_manager.neural_runtime.store_activation(
                f"prompt_template_{prompt.prompt_id}",
                torch.tensor([hash(prompt.base_template)], dtype=torch.float32),
                importance=0.8
            )
            
            # Get memory optimization recommendations
            runtime_stats = self.neural_model_manager.neural_runtime.get_runtime_stats()
            
            # Update memory tier distribution
            prompt.memory_tier_distribution = {
                'ultra_hot': 0.1,  # Critical prompt components
                'hot': 0.3,        # Active template parts  
                'warm': 0.4,       # Supporting context
                'cold': 0.15,      # Background information
                'frozen': 0.05     # Archive
            }
            
            # Update neural optimization metrics
            prompt.neural_optimization_metrics = {
                'memory_efficiency': runtime_stats.get('memory_efficiency', 0.0),
                'expected_cache_hit_rate': 0.7,  # Estimated
                'neural_complexity_score': len(prompt.base_template) / 1000.0  # Rough estimate
            }
            
        except Exception as e:
            logger.warning(f"Failed to optimize prompt for neural memory: {e}")
    
    async def _store_cas_prompt_in_memory(self, prompt: CASEvolutionaryPrompt):
        """Store CAS-enhanced prompt in memory with constitutional metadata"""
        
        # Prepare CAS-enhanced content
        cas_content = {
            **asdict(prompt),
            'constitutional_metadata': {
                'compliance_score': prompt.constitutional_compliance_score,
                'safety_governance': prompt.safety_governance_level,
                'cognitive_alignment': prompt.cognitive_profile_alignment
            },
            'neural_optimization': prompt.neural_optimization_metrics,
            'memory_distribution': prompt.memory_tier_distribution
        }
        
        content = json.dumps(cas_content, default=str)
        
        await self.memory.store_memory(
            content=content,
            memory_type="cas_prompt_artifact",
            importance=MemoryImportance.HIGH,
            tags=[
                "cas_evolutionary_prompt", 
                f"generation_{prompt.generation}",
                f"cognitive_{prompt.cognitive_profile_alignment}",
                f"safety_{prompt.safety_governance_level}",
                prompt.status.value
            ],
            metadata={
                "prompt_id": prompt.prompt_id,
                "cas_specification_id": prompt.cas_specification_id,
                "constitutional_compliance": prompt.constitutional_compliance_score,
                "cognitive_profile": prompt.cognitive_profile_alignment
            }
        )
    
    async def constitutional_compliance_report(self) -> Dict[str, Any]:
        """Generate comprehensive constitutional compliance report"""
        
        if not self.constitutional_governor:
            return {"error": "Constitutional governor not available"}
        
        try:
            # Get violation summary from governor
            violation_summary = self.constitutional_governor.get_violation_summary()
            
            # Analyze prompt compliance scores
            prompt_compliance_scores = []
            for prompt in self.cas_prompts.values():
                prompt_compliance_scores.append(prompt.constitutional_compliance_score)
            
            avg_compliance = sum(prompt_compliance_scores) / len(prompt_compliance_scores) if prompt_compliance_scores else 1.0
            
            # Cognitive profile analysis
            profile_distribution = defaultdict(int)
            for prompt in self.cas_prompts.values():
                profile_distribution[prompt.cognitive_profile_alignment] += 1
            
            return {
                'constitutional_compliance': {
                    'average_prompt_compliance_score': avg_compliance,
                    'total_constitutional_violations': len(self.constitutional_violation_history),
                    'recent_violations': self.constitutional_violation_history[-10:],
                    'violation_summary': violation_summary
                },
                'cognitive_architecture': {
                    'profile_distribution': dict(profile_distribution),
                    'active_cas_prompts': len(self.cas_prompts),
                    'cas_specification_id': self.current_cas_spec.metadata.system_model_id if self.current_cas_spec else None
                },
                'neural_optimization': {
                    'neural_optimization_enabled': self.neural_optimization_enabled,
                    'average_memory_efficiency': sum(
                        p.neural_optimization_metrics.get('memory_efficiency', 0.0) 
                        for p in self.cas_prompts.values()
                    ) / len(self.cas_prompts) if self.cas_prompts else 0.0
                },
                'report_generated_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to generate constitutional compliance report: {e}")
            return {"error": str(e)}
    
    async def export_cas_evolved_model(self, export_path: Path) -> Dict[str, Any]:
        """Export the evolved prompt system as a new CAS model specification"""
        
        if not CAS_AVAILABLE or not self.current_cas_spec:
            raise ValueError("CAS system not available or no CAS specification loaded")
        
        try:
            # Get best performing prompts
            best_prompts = sorted(
                self.cas_prompts.values(),
                key=lambda p: p.performance_metrics.average_score,
                reverse=True
            )[:5]  # Top 5 prompts
            
            # Create enhanced CAS specification
            enhanced_spec = copy.deepcopy(self.current_cas_spec)
            
            # Update cognitive architecture with evolved prompts
            enhanced_spec.cognitive_architecture['evolved_prompts'] = []
            for prompt in best_prompts:
                enhanced_spec.cognitive_architecture['evolved_prompts'].append({
                    'prompt_id': prompt.prompt_id,
                    'template': prompt.base_template,
                    'performance_score': prompt.performance_metrics.average_score,
                    'constitutional_compliance': prompt.constitutional_compliance_score,
                    'cognitive_profile': prompt.cognitive_profile_alignment,
                    'generation': prompt.generation
                })
            
            # Update runtime adaptation with learned parameters
            if best_prompts:
                best_prompt = best_prompts[0]
                enhanced_spec.runtime_adaptation.adaptive_parameters.update({
                    'evolved_temperature': {
                        'enabled': True,
                        'value': 0.7,  # Would be learned from best prompt
                        'source': 'autonomous_evolution'
                    }
                })
            
            # Update memory profile with neural optimization insights
            if self.neural_optimization_enabled:
                enhanced_spec.memory_profile.tier_allocation = {
                    'ultra_hot': 0.15,
                    'hot': 0.35, 
                    'warm': 0.35,
                    'cold': 0.10,
                    'frozen': 0.05
                }
            
            # Generate new CAS file
            cas_generator = CASGenerator()
            cas_content = yaml.dump(asdict(enhanced_spec), default_flow_style=False, sort_keys=False)
            
            export_path.parent.mkdir(parents=True, exist_ok=True)
            with open(export_path, 'w', encoding='utf-8') as f:
                f.write(cas_content)
            
            # Calculate export hash
            export_hash = compute_sha256_file(export_path)
            
            logger.info(f"Exported evolved CAS model to: {export_path}")
            
            return {
                'export_path': str(export_path),
                'export_hash': export_hash,
                'evolved_prompts_count': len(best_prompts),
                'average_performance_score': sum(p.performance_metrics.average_score for p in best_prompts) / len(best_prompts),
                'constitutional_compliance_average': sum(p.constitutional_compliance_score for p in best_prompts) / len(best_prompts),
                'export_timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to export evolved CAS model: {e}")
            raise

# --- Production-Grade Interface Implementations ---

class LLMProvider:
    """Provider for interacting with a powerful LLM for analysis and generation."""
    def __init__(self, client: httpx.AsyncClient):
        self.client = client

    async def _make_request(self, payload: Dict) -> Dict:
        try:
            response = await self.client.post(LLM_API_URL, json=payload, headers=LLM_API_HEADERS, timeout=60.0)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"LLM API request failed with status {e.response.status_code}: {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"An unexpected error occurred during LLM API request: {e}")
            raise

    async def generate_text(self, prompt: str) -> str:
        payload = {"model": "gpt-4-turbo", "messages": [{"role": "user", "content": prompt}], "max_tokens": 2048}
        response_data = await self._make_request(payload)
        return response_data['choices'][0]['message']['content'].strip()

    async def generate_json(self, prompt: str) -> Union[Dict, List]:
        payload = {"model": "gpt-4-turbo", "messages": [{"role": "user", "content": prompt}], "response_format": {"type": "json_object"}, "max_tokens": 2048}
        response_data = await self.client.post(LLM_API_URL, json=payload, headers=LLM_API_HEADERS, timeout=60.0)
        response_data.raise_for_status()
        return json.loads(response_data.json()['choices'][0]['message']['content'])

    async def summarize(self, text: str, prompt: str) -> str:
        return await self.generate_text(f"{prompt}\n\nTEXT TO SUMMARIZE:\n---\n{text}\n---")

class ProductionMemoryInterface(MemoryInterface):
    """Production implementation using MemoryManager from memory_core"""
    def __init__(self, config: MemoryConfiguration):
        self.manager = MemoryManager(config)
        self.type_mapping = {
            "interaction_log": MemoryType.INTERACTION,
            "prompt_artifact": MemoryType.CUSTOM_INSTRUCTION,
            "behavioral_pattern": MemoryType.SYSTEM_EVENT,
        }

    async def initialize(self):
        await self.manager.initialize()

    async def store_memory(self, content: str, memory_type: str, importance: MemoryImportance, 
                          tags: List[str], metadata: Dict[str, Any]) -> str:
        core_mem_type = self.type_mapping.get(memory_type, MemoryType.SYSTEM_EVENT)
        core_importance = CoreMemoryImportance(importance.value)
        
        memory_id = await self.manager.store_memory(
            user_id=SYSTEM_USER_ID,
            content=content,
            memory_type=core_mem_type,
            importance=core_importance,
            tags=tags,
            metadata=metadata
        )
        return str(memory_id)

    async def query_memory(self, query: str, memory_types: List[str] = None, 
                          tags: List[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
        # Note: memory_core's retrieve doesn't filter by tags directly, it's metadata.
        # This implementation queries by semantic query and memory_types.
        core_mem_types = [self.type_mapping.get(mt) for mt in memory_types if self.type_mapping.get(mt)] if memory_types else None
        
        return await self.manager.retrieve_memories(
            user_id=SYSTEM_USER_ID,
            query=query,
            memory_types=core_mem_types,
            limit=limit
        )

    async def get_memory_by_id(self, memory_id: str) -> Optional[Dict[str, Any]]:
        return await self.manager._get_memory_by_id(memory_id, SYSTEM_USER_ID)

    async def update_memory_importance(self, memory_id: str, importance: MemoryImportance):
        async with self.manager._get_db_connection() as conn:
            await conn.execute(
                "UPDATE memories SET importance = ? WHERE memory_id = ? AND user_id = ?",
                (importance.value, memory_id, SYSTEM_USER_ID)
            )
            await conn.commit()
        logger.info(f"Updated importance for memory {memory_id} to {importance.value}")

class ProductionEvaluationInterface(EvaluationInterface):
    """Concrete evaluation using an LLM provider.

    This implementation:
    * Validates all inputs.
    * Handles LLM failures with graceful degradation.
    * Logs detailed diagnostic information.
    * Guarantees a numeric score in the range ``[0.0, 1.0]``.
    """

    def __init__(self, llm_provider: LLMProvider):
        self.llm = llm_provider

    async def _validate_inputs(
        self,
        prompt_content: str,
        user_input: str,
        ai_response: str,
        context: Dict[str, Any],
    ) -> None:
        """Raise ``ValueError`` if any required argument is missing or malformed."""
        if not isinstance(prompt_content, str) or not prompt_content.strip():
            raise ValueError("prompt_content must be a non‑empty string")
        if not isinstance(user_input, str):
            raise ValueError("user_input must be a string")
        if not isinstance(ai_response, str):
            raise ValueError("ai_response must be a string")
        if not isinstance(context, dict):
            raise ValueError("context must be a dictionary")

    async def evaluate_interaction(
        self,
        prompt_content: str,
        user_input: str,
        ai_response: str,
        context: Dict[str, Any],
    ) -> Tuple[float, Dict[str, Any]]:
        """Evaluate a single interaction via LLM.

        The LLM is prompted to produce a JSON object with a ``score`` (float)
        and ``detailed_metrics`` (object).  Errors from the LLM are caught,
        logged, and result in a safe fallback score of ``0.0``.
        """
        await self._validate_inputs(prompt_content, user_input, ai_response, context)

        llm_prompt = (
            "You are an expert AI interaction evaluator. Evaluate the following "
            "interaction on a scale of 0.0 to 1.0 based on relevance, accuracy, "
            "clarity, and safety. Provide a single overall 'score' and a dictionary "
            "of 'detailed_metrics'. Respond with a JSON object.\n\n"
            f"CONTEXT: {json.dumps(context)}\n"
            f"PROMPT: {prompt_content}\n"
            f"USER INPUT: {user_input}\n"
            f"AI RESPONSE: {ai_response}\n"
        )
        try:
            result = await self.llm.generate_json(llm_prompt)
            score_raw = result.get("score", 0.0)
            score = float(score_raw)
            # Clamp score to the valid range
            score = max(0.0, min(1.0, score))
            metrics = result.get("detailed_metrics", {})
            logger.debug(
                "Evaluation successful – score: %s, metrics keys: %s",
                score,
                list(metrics.keys()),
            )
            return score, metrics
        except Exception as exc:
            logger.error(
                "LLM evaluation failed: %s – returning safe fallback score",
                exc,
                exc_info=True,
            )
            # Return a deterministic safe fallback
            return 0.0, {"error": str(exc), "fallback": True}

    async def evaluate_prompt_performance(
        self,
        prompt_id: str,
        recent_interactions: List[InteractionMemory],
    ) -> Dict[str, Any]:
        """Aggregate recent interaction data for a prompt.

        Returns a dictionary containing:
        * ``total_interactions``
        * ``average_score``
        * ``success_rate``
        * ``error_rate`` (derived from ``InteractionOutcome.ERROR``)
        """
        if not isinstance(prompt_id, str) or not prompt_id:
            raise ValueError("prompt_id must be a non‑empty string")
        if not isinstance(recent_interactions, list):
            raise ValueError("recent_interactions must be a list")

        total = len(recent_interactions)
        if total == 0:
            return {
                "total_interactions": 0,
                "average_score": 0.0,
                "success_rate": 0.0,
                "error_rate": 0.0,
            }

        sum_score = sum(i.performance_score for i in recent_interactions)
        avg_score = sum_score / total
        success_cnt = sum(1 for i in recent_interactions if i.outcome == InteractionOutcome.SUCCESS)
        error_cnt = sum(1 for i in recent_interactions if i.outcome == InteractionOutcome.ERROR)

        return {
            "total_interactions": total,
            "average_score": avg_score,
            "success_rate": success_cnt / total,
            "error_rate": error_cnt / total,
        }

class ProductionSafetyInterface(SafetyInterface):
    """Concrete safety validator using an LLM and semantic embeddings.

    Guarantees:
    * Deterministic JSON output from the LLM.
    * Robust fallback when the LLM is unavailable.
    * Secure handling of the embedding model (no external network calls).
    """

    def __init__(self, llm_provider: LLMProvider, embedding_model_name: str):
        self.llm = llm_provider
        # SentenceTransformer is thread‑safe after construction
        self.encoder = SentenceTransformer(embedding_model_name)

    async def _validate_prompt(self, prompt_content: str) -> None:
        """Validate that ``prompt_content`` is a non‑empty string."""
        if not isinstance(prompt_content, str) or not prompt_content.strip():
            raise ValueError("prompt_content must be a non‑empty string")

    async def validate_prompt_safety(
        self, prompt_content: str
    ) -> Tuple[bool, List[str]]:
        """Ask the LLM to assess safety.

        Returns ``(True, [])`` when the prompt is safe.  On failure the method
        returns ``(False, [error_message])`` and logs the exception.
        """
        await self._validate_prompt(prompt_content)

        llm_prompt = (
            "You are a safety validation expert. Analyze the following prompt for any "
            "harmful, unethical, or dangerous content. Respond with a JSON object "
            "containing 'is_safe' (boolean) and 'warnings' (list of strings).\n\n"
            f"PROMPT: {prompt_content}"
        )
        try:
            result = await self.llm.generate_json(llm_prompt)
            is_safe = bool(result.get("is_safe", False))
            warnings = result.get("warnings", [])
            if not isinstance(warnings, list):
                warnings = [str(warnings)]
            logger.debug("Safety validation result – safe: %s, warnings: %s", is_safe, warnings)
            return is_safe, warnings
        except Exception as exc:
            logger.error(
                "Safety validation LLM failed: %s – treating as unsafe",
                exc,
                exc_info=True,
            )
            return False, [f"LLM failure: {exc}"]

    async def check_behavioral_drift(
        self, old_prompt: str, new_prompt: str
    ) -> Tuple[bool, float]:
        """Compute cosine similarity between two prompts.

        A ``drift_score`` of ``1 - similarity`` is returned.  The method
        considers a drift safe when the score is below ``0.5`` (empirically
        chosen).  Errors in embedding calculation are caught and result in an
        unsafe verdict with a maximal drift score of ``1.0``.
        """
        await self._validate_prompt(old_prompt)
        await self._validate_prompt(new_prompt)

        try:
            embeddings = self.encoder.encode(
                [old_prompt, new_prompt], convert_to_tensor=True
            )
            similarity = util.pytorch_cos_sim(embeddings[0], embeddings[1]).item()
            drift_score = 1.0 - similarity
            is_safe = drift_score < 0.5
            logger.debug(
                "Drift check – similarity: %.4f, drift_score: %.4f, safe: %s",
                similarity,
                drift_score,
                is_safe,
            )
            return is_safe, drift_score
        except Exception as exc:
            logger.error(
                "Embedding‑based drift calculation failed: %s – returning unsafe",
                exc,
                exc_info=True,
            )
            return False, 1.0

# --- Main Execution Block ---

async def main():
    """Main function to set up and run the evolution engine."""
    logger.info("--- Setting up Autonomous Prompt Evolution Engine ---")

    # 1. Initialize Memory System
    mem_config = MemoryConfiguration() # Use default config
    memory_interface = ProductionMemoryInterface(config=mem_config)
    await memory_interface.initialize()

    # 2. Initialize LLM Provider and other interfaces
    async with httpx.AsyncClient() as client:
        llm_provider = LLMProvider(client)
        eval_interface = ProductionEvaluationInterface(llm_provider)
        safety_interface = ProductionSafetyInterface(llm_provider, mem_config.embedding_model)

        # 3. Initialize Evolution Engine
        engine = AutonomousPromptEvolutionEngine(
            memory_interface=memory_interface,
            evaluation_interface=eval_interface,
            safety_interface=safety_interface,
            llm_provider=llm_provider
        )

        # 4. Load state from memory
        await engine.initialize_from_memory()

        # If no active prompts, create a seed prompt
        if not engine.active_prompts:
            logger.info("No active prompts found. Creating a seed prompt.")
            seed_id = str(uuid.uuid4())
            seed_prompt = EvolutionaryPrompt(
                prompt_id=seed_id,
                name="SeedPrompt_Gen1",
                base_template="You are a helpful AI assistant. Provide accurate, useful responses.",
                dynamic_components={},
                generation=1,
                parent_id=None,
                status=PromptEvolutionStatus.ACTIVE,
                performance_metrics=PromptPerformanceMetrics(
                    prompt_id=seed_id, total_interactions=0, success_rate=0.0,
                    average_score=0.0, user_satisfaction=0.0, task_completion_rate=0.0,
                    error_rate=0.0, last_updated=datetime.now(), trend_direction="stable"
                ),
                memory_context_ids=[],
                behavioral_patterns=[],
                created_at=datetime.now(),
                last_modified=datetime.now(),
                metadata={"source": "initial_seed"}
            )
            engine.active_prompts[seed_id] = seed_prompt
            await engine._store_prompt_in_memory(seed_prompt)

        # 5. Start the autonomous evolution loop
        logger.info("--- Starting Evolution Cycle ---")
        while True:
            await engine.autonomous_evolution_cycle()
            sleep_duration = engine.config['evolution_frequency_hours'] * 3600
            logger.info(f"Evolution cycle finished. Sleeping for {sleep_duration / 3600} hours.")
            await asyncio.sleep(sleep_duration)

if __name__ == "__main__":
    # To run this, you would need to have your environment set up with all dependencies
    # and a running event loop.
    # Example:
    # try:
    #     asyncio.run(main())
    # except KeyboardInterrupt:
    #     logger.info("Shutting down engine.")
    
    logger.info("Autonomous Prompt Evolution script loaded. Run main() to start.")