# Gemini Code Assistant Context

## Project: Somnus Sovereign Systems

This document provides the necessary context for the Gemini Code Assistant to effectively understand and assist with the development of the Somnus Sovereign Systems project.

### Project Overview

The Somnus Sovereign Systems project is a local-first, AI-augmented operating system designed for complete digital sovereignty. It is a "SaaS-Killer" that aims to provide all the functionalities of cloud-based AI services (like Claude, ChatGPT) and more, but running entirely on the user's local machine. The core philosophy emphasizes local data storage, persistent AI intelligence, unlimited execution time, and a revolutionary dual-layer architecture.

The system architecture follows a modular design:

1.  **Persistent AI Intelligence Layer (Virtual Machines):** Each AI agent or project gets its own persistent Virtual Machine (VM) that never resets. This allows the AI to learn and accumulate knowledge over time. The VM management is handled by the `vm_supervisor.py` using `libvirt`.
2.  **Disposable Computation Layer (Container Overlays):** For heavy computational tasks, the system uses disposable Docker containers. This provides a secure and isolated environment for tasks like model training, video processing, and running complex code, without bloating the persistent VM. This is managed by the `artifact_container_runtime.py` and `artifact_config.py`.
3.  **Persistent Memory Core:** The system has a sophisticated memory system that allows AI agents to have long-term memory. It uses `ChromaDB` for semantic vector storage and `sqlite3` for metadata, managed by `memory_core.py`.
4.  **Web Research and OSINT:** The system has a triple-layer web research capability, including a browser in the VM, chat-integrated search, and a dedicated deep research engine.

### Technical Stack

*   **Language:** Python 3.11+
*   **Framework:** FastAPI
*   **Virtualization:** Libvirt with QEMU/KVM
*   **Containerization:** Docker
*   **Vector Database:** ChromaDB
*   **Dependencies:** See `requirements.txt` for a full list.

### Building and Running

1.  **Clone and Setup:**
    ```bash
    git clone https://github.com/somnus-systems/sovereign-ai.git
    cd somnus-sovereign-ai
    python -m venv venv
    source venv/bin/activate  # Linux/macOS
    # or venv\Scripts\activate  # Windows
    pip install -r requirements.txt
    ```

2.  **Initialize Base VM Image:**
    ```bash
    # Build base AI computer image
    docker build -f configs/dockerfile_base.txt -t somnus-base:latest .

    # Create VM template
    python scripts/create_vm_template.py --base-image somnus-base:latest
    ```

3.  **Configure System:**
    ```bash
    cp configs/base_config.yaml configs/local_config.yaml
    # Edit local_config.yaml with your hardware specifications
    ```

4.  **Start Somnus:**
    ```bash
    python main.py --config configs/local_config.yaml --port 8000
    ```
    The system will be available at `http://localhost:8000`.

### Development Conventions

*   **Configuration:** All project configurations are centralized in `.yaml` files in the `configs/` directory.
*   **Modularity:** The codebase is organized into modules within the `core/`, `backend/`, `projects/`, `security/`, `settings/`, and `web_research/` directories, following a clear separation of concerns.
*   **Local-First:** The system is designed to run entirely locally, with no reliance on cloud services for core functionality.
*   **Persistent AI:** The AI's state, memory, and tools are persisted across sessions in dedicated VMs.
*   **Unlimited Execution:** The artifact system allows for unlimited execution time and resources within disposable containers.
